import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Badge } from "react-native-paper";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const MenuItem3 = memo(({ style }) => {
  return (
    <View style={[styles.menuItem, style]}>
      <View style={styles.iconlylightnotification}>
        <Image
          style={styles.notificationIcon}
          contentFit="cover"
          source={require("../assets/notification.png")}
        />
        <Badge style={styles.oval} size={10} visible={true} />
      </View>
      <Text style={styles.notification}>Notification</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  notificationIcon: {
    height: "87.17%",
    width: "77.08%",
    top: "5.21%",
    right: "11.46%",
    bottom: "7.62%",
    left: "11.46%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  oval: {
    top: 0,
    left: 12,
    backgroundColor: Color.orange_100,
    position: "absolute",
  },
  iconlylightnotification: {
    width: 24,
    height: 24,
  },
  notification: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.black,
    textAlign: "left",
    marginLeft: 16,
  },
  menuItem: {
    width: 124,
    flexDirection: "row",
    height: 24,
  },
});

export default MenuItem3;
