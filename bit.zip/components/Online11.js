import React, { memo } from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Online11 = memo(({ style }) => {
  return (
    <View style={[styles.online1, style]}>
      <Text style={styles.online}>Online</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  online: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.white,
    textAlign: "center",
    width: 64,
  },
  online1: {
    borderRadius: Border.br_13xl,
    backgroundColor: Color.cornflowerblue,
    width: 153,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_7xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Online11;
