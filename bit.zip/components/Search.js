import React, { memo } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import Online from "./Online";
import Offline from "./Offline";
import Online11 from "./Online11";
import Online2 from "./Online2";
import Offline2 from "./Offline2";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import FormSection from "./FormSection";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const TopTab = createMaterialTopTabNavigator();
const Search = memo(() => {
  const navigation = useNavigation();

  return (
    <View style={styles.search}>
      <ScrollView
        style={[styles.searchPageBody, styles.outlinedtextIconFlexBox]}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.searchPageBodyContent}
      >
        <View style={[styles.event2, styles.event2ShadowBox]}>
          <TopTab.Navigator
            style={styles.firstToptabs}
            tabBar={({ state, descriptors, navigation, position }) => {
              const [activeItems] = React.useState([
                <Online11 />,
                <Offline2 />,
              ]);
              const [normalItems] = React.useState([<Online2 />, <Online2 />]);
              const activeIndex = state.index;
              return (
                <View style={styles.topTabBarStyle}>
                  {normalItems.map((item, index) => {
                    const isFocused = state.index === index;
                    return (
                      <TouchableOpacity
                        key={index}
                        onPress={() => {
                          navigation.navigate({
                            name: state.routes[index].name,
                            merge: true,
                          });
                        }}
                      >
                        {activeIndex === index ? activeItems[index] : item}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              );
            }}
          >
            <TopTab.Screen name="online" component={Online} />
            <TopTab.Screen name="offline" component={Offline} />
          </TopTab.Navigator>
        </View>
        <FormSection
          dimensions={require("../assets/offer-image2.png")}
          carDimensions={require("../assets/offer-image3.png")}
          propMarginTop={20}
          onOfferCardPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
          }
          onOfferCardPress1={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
          }
        />
      </ScrollView>
    </View>
  );
});

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  firstToptabs: {
    width: "100%",
    height: 450,
  },
  topTabBarStyle: {
    borderRadius: 32,
    backgroundColor: "#f3f5f9",
    width: 313,
    flexDirection: "row",
    padding: 4,
    alignItems: "flex-start",
    justifyContent: "flex-start",
    minHeight: 44,
    zIndex: 1,
  },
  searchPageBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 15,
    paddingVertical: 16,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  outlinedtextIconFlexBox: {
    flex: 1,
    alignSelf: "stretch",
  },
  event2ShadowBox: {
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    backgroundColor: Color.white,
  },
  buttonPrimaryFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  exploreTypo: {
    marginTop: 14,
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_smi,
    textAlign: "center",
  },
  event2: {
    borderRadius: Border.br_xs,
    width: 341,
    height: 465,
    padding: Padding.p_sm,
  },
  searchPageBody: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
  search: {
    width: 371,
    height: 786,
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
});

export default Search;
