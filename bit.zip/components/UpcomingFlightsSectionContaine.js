import React, { memo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Padding, Border } from "../GlobalStyles";

const UpcomingFlightsSectionContaine = memo(() => {
  return (
    <View style={styles.upcomingFlightsSection}>
      <Text style={[styles.freeEvents, styles.bitClr]}>Free Events</Text>
      <View style={styles.frameParent}>
        <View style={styles.group13Parent}>
          <View>
            <Text style={[styles.seminar, styles.daysTypo]}>SEMINAR</Text>
            <Text style={[styles.bit, styles.bitClr]}>BIT</Text>
          </View>
          <View style={[styles.line2Parent, styles.parentFlexBox]}>
            <Image
              style={[styles.line2Icon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/line2.png")}
            />
            <Image
              style={[styles.ovalIcon, styles.ovalIconLayout]}
              contentFit="cover"
              source={require("../assets/oval.png")}
            />
            <Image
              style={styles.iconFlight}
              contentFit="cover"
              source={require("../assets/icon--flight.png")}
            />
            <Image
              style={[styles.ovalIcon1, styles.ovalIconLayout]}
              contentFit="cover"
              source={require("../assets/oval.png")}
            />
          </View>
          <View style={styles.group131}>
            <Text style={[styles.seminar, styles.daysTypo]}>WEBINAR</Text>
            <Text style={[styles.bit, styles.bitClr]}>PSG</Text>
          </View>
        </View>
        <Image
          style={[styles.line3Icon, styles.line3IconSpaceBlock]}
          contentFit="cover"
          source={require("../assets/line3.png")}
        />
        <View
          style={[styles.startsOn21Aug0800AmParent, styles.line3IconSpaceBlock]}
        >
          <Text style={[styles.startsOn21, styles.startsOn21Typo]}>
            Starts on: 21 Aug, 08:00 AM
          </Text>
          <Text style={styles.startsOn21Typo}>
            <Text style={styles.daysTypo}>4 days</Text>
            <Text style={styles.toGo}> to go</Text>
          </Text>
        </View>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  bitClr: {
    color: Color.black,
    textAlign: "left",
  },
  daysTypo: {
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  parentFlexBox: {
    justifyContent: "space-between",
    flexDirection: "row",
  },
  iconLayout: {
    maxWidth: "100%",
    overflow: "hidden",
  },
  ovalIconLayout: {
    height: 10,
    width: 10,
  },
  line3IconSpaceBlock: {
    marginTop: 16,
    alignSelf: "stretch",
  },
  startsOn21Typo: {
    color: Color.lightslategray,
    fontSize: FontSize.size_mini,
    textAlign: "left",
  },
  freeEvents: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    textAlign: "left",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  seminar: {
    fontSize: FontSize.size_xl,
    color: Color.cornflowerblue,
    textAlign: "left",
  },
  bit: {
    fontSize: FontSize.pxRegular_size,
    marginTop: 4,
    fontFamily: FontFamily.interRegular,
    textAlign: "left",
  },
  line2Icon: {
    position: "absolute",
    marginTop: -1.55,
    top: "50%",
    right: 8,
    left: 8,
    height: 2,
    zIndex: 0,
  },
  ovalIcon: {
    zIndex: 1,
  },
  iconFlight: {
    width: 36,
    height: 37,
    zIndex: 2,
  },
  ovalIcon1: {
    zIndex: 3,
  },
  line2Parent: {
    flex: 1,
    marginLeft: 18,
    alignItems: "center",
  },
  group131: {
    alignItems: "flex-end",
    marginLeft: 18,
  },
  group13Parent: {
    paddingTop: Padding.p_xs,
    alignItems: "center",
    paddingHorizontal: Padding.p_xs,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  line3Icon: {
    height: 1,
    width: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  startsOn21: {
    fontFamily: FontFamily.robotoRegular,
  },
  toGo: {
    fontFamily: FontFamily.interRegular,
  },
  startsOn21Aug0800AmParent: {
    paddingBottom: Padding.p_xs,
    justifyContent: "space-between",
    flexDirection: "row",
    paddingHorizontal: Padding.p_xs,
  },
  frameParent: {
    borderRadius: Border.br_5xs,
    backgroundColor: Color.white,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    marginTop: 14,
    overflow: "hidden",
    alignSelf: "stretch",
  },
  upcomingFlightsSection: {
    alignSelf: "stretch",
  },
});

export default UpcomingFlightsSectionContaine;
