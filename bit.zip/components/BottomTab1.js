import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const BottomTab1 = memo(({ style }) => {
  return (
    <View style={[styles.bottomTab, style]}>
      <Image
        style={styles.ggprofileIcon}
        contentFit="cover"
        source={require("../assets/ggprofile1.png")}
      />
      <Text style={styles.profile}>Profile</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  ggprofileIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  profile: {
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.robotoRegular,
    color: Color.darkslateblue,
    textAlign: "center",
    marginTop: 14,
  },
  bottomTab: {
    width: 61,
    alignItems: "center",
  },
});

export default BottomTab1;
