import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const MenuItem = memo(({ style }) => {
  return (
    <View style={[styles.menuItem, style]}>
      <Image
        style={styles.rateIcon}
        contentFit="cover"
        source={require("../assets/rate.png")}
      />
      <Text style={styles.faulty}>Faulty</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  rateIcon: {
    width: 24,
    overflow: "hidden",
    height: 24,
  },
  faulty: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.black,
    textAlign: "left",
    marginLeft: 16,
  },
  menuItem: {
    flexDirection: "row",
    height: 24,
  },
});

export default MenuItem;
