import React, { memo } from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const SignupFaculty = memo(({ style }) => {
  return (
    <View style={[styles.signupFaculty, style]}>
      <Text style={styles.signUp}>Sign up</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  signUp: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontFamily: FontFamily.robotoRegular,
    color: Color.darkgray_100,
    textAlign: "center",
  },
  signupFaculty: {
    borderRadius: Border.br_13xl,
    width: 153,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_7xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default SignupFaculty;
