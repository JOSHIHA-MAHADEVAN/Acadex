import React, { memo } from "react";
import {
  Pressable,
  StyleProp,
  ViewStyle,
  StyleSheet,
  Text,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const MenuItem1 = memo(({ style }) => {
  const navigation = useNavigation();

  return (
    <TouchableOpacity
      style={[styles.menuItem, style]}
      activeOpacity={0.2}
      onPress={() => navigation.navigate("StudentSignup")}
    >
      <Image
        style={styles.calenderIcon}
        contentFit="cover"
        source={require("../assets/calender.png")}
      />
      <Text style={styles.signUp}>Sign up</Text>
    </TouchableOpacity>
  );
});

const styles = StyleSheet.create({
  calenderIcon: {
    width: 24,
    overflow: "hidden",
    height: 24,
  },
  signUp: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.black,
    textAlign: "left",
    marginLeft: 16,
  },
  menuItem: {
    width: 169,
    flexDirection: "row",
    height: 24,
  },
});

export default MenuItem1;
