import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Photo5Image2 = memo(({ style }) => {
  return (
    <Image
      style={[styles.photo5Icon, style]}
      contentFit="cover"
      source={require("../assets/photo19.png")}
    />
  );
});

const styles = StyleSheet.create({
  photo5Icon: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 90,
  },
});

export default Photo5Image2;
