import React, { memo } from "react";
import {
  View,
  StyleProp,
  ViewStyle,
  Pressable,
  StyleSheet,
  Text,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { Badge } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const Header = memo(({ style }) => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={[styles.header, style]}>
      <View style={styles.view}>
        <Pressable
          style={styles.hamburgerIcon}
          onPress={() => navigation.toggleDrawer()}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/hamburger-icon.png")}
          />
        </Pressable>
        <Text style={styles.acadex}>ACADEX</Text>
        <Pressable
          style={styles.profile}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Profile" })
          }
        >
          <Image
            style={styles.group3Icon}
            contentFit="cover"
            source={require("../assets/group3.png")}
          />
          <Badge style={styles.oval} size={10} visible={true} />
        </Pressable>
      </View>
    </SafeAreaView>
  );
});

const styles = StyleSheet.create({
  header: {
    backgroundColor: Color.white,
  },
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  hamburgerIcon: {
    width: 32,
    height: 32,
  },
  acadex: {
    fontSize: FontSize.size_9xl,
    fontFamily: FontFamily.jotiOneRegular,
    color: Color.black,
    textAlign: "right",
    width: 105,
    height: 30,
    opacity: 0.6,
  },
  group3Icon: {
    width: 36,
    height: 36,
    zIndex: 0,
  },
  oval: {
    position: "absolute",
    top: 0,
    left: 26,
    backgroundColor: Color.orange_100,
    zIndex: 1,
  },
  profile: {
    flexDirection: "row",
  },
  view: {
    alignSelf: "stretch",
    padding: Padding.p_base,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
});

export default Header;
