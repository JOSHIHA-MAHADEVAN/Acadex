import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const PhotoImage4 = memo(({ style }) => {
  return (
    <Image
      style={[styles.photoIcon, style]}
      contentFit="cover"
      source={require("../assets/photo4.png")}
    />
  );
});

const styles = StyleSheet.create({
  photoIcon: {
    borderRadius: Border.br_9xs,
    width: 343,
    height: 197,
  },
});

export default PhotoImage4;
