import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Photo6Image5 = memo(({ style }) => {
  return (
    <Image
      style={[styles.photo6Icon, style]}
      contentFit="cover"
      source={require("../assets/photo36.png")}
    />
  );
});

const styles = StyleSheet.create({
  photo6Icon: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 90,
  },
});

export default Photo6Image5;
