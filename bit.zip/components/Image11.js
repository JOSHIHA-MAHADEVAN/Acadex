import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Image11 = memo(({ style }) => {
  return (
    <Image
      style={[styles.image11Icon, style]}
      contentFit="cover"
      source={require("../assets/image-11.png")}
    />
  );
});

const styles = StyleSheet.create({
  image11Icon: {
    borderRadius: Border.br_9xs,
    width: 104,
    height: 71,
  },
});

export default Image11;
