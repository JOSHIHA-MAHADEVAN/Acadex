import React, { memo } from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Offline1 = memo(({ style }) => {
  return (
    <View style={[styles.offline1, style]}>
      <Text style={styles.login}>Login</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  login: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontFamily: FontFamily.robotoRegular,
    color: Color.darkgray_100,
    textAlign: "center",
  },
  offline1: {
    borderRadius: Border.br_13xl,
    width: 153,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_7xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Offline1;
