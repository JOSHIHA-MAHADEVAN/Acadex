import React, { memo } from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Online2 = memo(({ style }) => {
  return (
    <View style={[styles.online2, style]}>
      <Text style={styles.online}>Online</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  online: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontFamily: FontFamily.robotoRegular,
    color: Color.darkgray_100,
    textAlign: "center",
  },
  online2: {
    borderRadius: Border.br_13xl,
    width: 153,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_7xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Online2;
