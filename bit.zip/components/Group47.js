import React, { memo } from "react";
import {
  View,
  StyleProp,
  ViewStyle,
  Pressable,
  StyleSheet,
  Text,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const Group47 = memo(({ style }) => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={[styles.group4, style]}>
      <View style={styles.view}>
        <Pressable
          style={styles.iconLayout6}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/icon--back.png")}
          />
        </Pressable>
        <View style={styles.innerFlexBox6}>
          <View style={[styles.eventsWrapper, styles.innerFlexBox6]}>
            <Text style={styles.events}>Events</Text>
          </View>
        </View>
        <View style={[styles.iconKebab, styles.iconLayout6]}>
          <View style={styles.ellipseParent}>
            <Image
              style={styles.frameLayout6}
              contentFit="cover"
              source={require("../assets/ellipse-1.png")}
            />
            <Image
              style={[styles.frameItem, styles.frameLayout6]}
              contentFit="cover"
              source={require("../assets/ellipse-2.png")}
            />
            <Image
              style={[styles.frameItem, styles.frameLayout6]}
              contentFit="cover"
              source={require("../assets/ellipse-3.png")}
            />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
});

const styles = StyleSheet.create({
  group4: {
    backgroundColor: Color.white,
  },
  innerFlexBox6: {
    justifyContent: "center",
    alignItems: "center",
  },
  iconLayout6: {
    height: 32,
    width: 32,
  },
  frameLayout6: {
    height: 5,
    width: 5,
  },
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  events: {
    fontSize: FontSize.size_base,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.black,
    textAlign: "left",
  },
  eventsWrapper: {
    flexDirection: "row",
    justifyContent: "center",
  },
  frameItem: {
    marginTop: 4,
  },
  ellipseParent: {
    position: "absolute",
    top: 5,
    left: 14,
  },
  iconKebab: {
    overflow: "hidden",
  },
  view: {
    alignSelf: "stretch",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_sm,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
});

export default Group47;
