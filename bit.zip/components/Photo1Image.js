import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Photo1Image = memo(({ style }) => {
  return (
    <Image
      style={[styles.photo1Icon, style]}
      contentFit="cover"
      source={require("../assets/photo11.png")}
    />
  );
});

const styles = StyleSheet.create({
  photo1Icon: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 90,
  },
});

export default Photo1Image;
