import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const BottomTab8 = memo(({ style }) => {
  return (
    <View style={[styles.bottomTab, style]}>
      <Image
        style={styles.uilbooksIcon}
        contentFit="cover"
        source={require("../assets/uilbooks1.png")}
      />
      <Text style={styles.explore}>Explore</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  uilbooksIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  explore: {
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.robotoRegular,
    color: Color.lightslategray,
    textAlign: "center",
    marginTop: 14,
  },
  bottomTab: {
    width: 61,
    alignItems: "center",
  },
});

export default BottomTab8;
