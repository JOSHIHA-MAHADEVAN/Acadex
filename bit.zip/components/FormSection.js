import React, { useMemo, memo } from "react";
import {
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  View,
  ImageSourcePropType,
} from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const FormSection = memo(
  ({
    dimensions,
    carDimensions,
    propMarginTop,
    onOfferCardPress,
    onOfferCardPress1,
  }) => {
    const offersSectionStyle = useMemo(() => {
      return {
        ...getStyleValue("marginTop", propMarginTop),
      };
    }, [propMarginTop]);

    return (
      <View style={[styles.offersSection, offersSectionStyle]}>
        <Text style={styles.certificates}>Certificates</Text>
        <ScrollView
          style={styles.offersRow}
          horizontal={true}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.offersRowScrollViewContent}
        >
          <Pressable
            style={styles.offerCardShadowBox}
            onPress={onOfferCardPress}
          >
            <View style={styles.offerDetails} />
            <Text
              style={[styles.internshipCertificate, styles.readMorePosition]}
            >
              Internship Certificate
            </Text>
            <Image
              style={[styles.offerImageIcon, styles.offerIconPosition]}
              contentFit="cover"
              source={dimensions}
            />
            <Text style={[styles.readMore, styles.readTypo]}>Read more!</Text>
          </Pressable>
          <Pressable
            style={[styles.offerCard1, styles.offerCardShadowBox]}
            onPress={onOfferCardPress1}
          >
            <Text
              style={[styles.onlineCourseCertificate, styles.readMore1Position]}
            >
              Online Course Certificate
            </Text>
            <Image
              style={[styles.offerImageIcon1, styles.offerIconPosition]}
              contentFit="cover"
              source={carDimensions}
            />
            <Text style={[styles.readMore1, styles.readMore1Position]}>
              Read more!
            </Text>
          </Pressable>
        </ScrollView>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  offersRowScrollViewContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  readMorePosition: {
    width: 136,
    left: 99,
    position: "absolute",
    textAlign: "left",
  },
  offerIconPosition: {
    height: 44,
    left: 21,
    top: 21,
    position: "absolute",
  },
  readTypo: {
    color: Color.gray999,
    fontFamily: FontFamily.robotoRegular,
    lineHeight: 18,
    fontSize: FontSize.size_xs,
    top: 47,
  },
  offerCardShadowBox: {
    height: 86,
    width: 264,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xs,
  },
  readMore1Position: {
    left: 100,
    position: "absolute",
    textAlign: "left",
  },
  certificates: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontFamily: FontFamily.interBold,
    textAlign: "left",
    color: Color.black,
    fontWeight: "700",
  },
  offerDetails: {
    top: 13,
    left: 112,
    position: "absolute",
  },
  internshipCertificate: {
    fontFamily: FontFamily.robotoBold,
    lineHeight: 19,
    fontSize: FontSize.pxRegular_size,
    top: 29,
    color: Color.black,
    fontWeight: "700",
  },
  offerImageIcon: {
    width: 63,
  },
  readMore: {
    width: 136,
    left: 99,
    position: "absolute",
    textAlign: "left",
  },
  onlineCourseCertificate: {
    width: 164,
    fontFamily: FontFamily.robotoBold,
    lineHeight: 19,
    fontSize: FontSize.pxRegular_size,
    top: 29,
    color: Color.black,
    fontWeight: "700",
  },
  offerImageIcon1: {
    width: 64,
  },
  readMore1: {
    width: 130,
    height: 14,
    color: Color.gray999,
    fontFamily: FontFamily.robotoRegular,
    lineHeight: 18,
    fontSize: FontSize.size_xs,
    top: 47,
  },
  offerCard1: {
    marginLeft: 16,
  },
  offersRow: {
    width: "100%",
    marginTop: 14,
    alignSelf: "stretch",
  },
  offersSection: {
    marginTop: 30,
    alignSelf: "stretch",
  },
});

export default FormSection;
