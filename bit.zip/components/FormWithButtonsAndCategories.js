import React, { memo } from "react";
import {
  ScrollView,
  Pressable,
  Text,
  StyleSheet,
  View,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import TagFlight from "./TagFlight";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const FormWithButtonsAndCategories = memo(() => {
  const navigation = useNavigation();

  return (
    <ScrollView
      style={styles.categories}
      horizontal={true}
      showsVerticalScrollIndicator={false}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.categoriesScrollViewContent}
    >
      <TouchableOpacity
        style={styles.card1}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("Internship")}
      >
        <View style={styles.internshipParent}>
          <Text style={[styles.internship, styles.internshipTypo]}>
            Internship
          </Text>
          <TagFlight
            tagFlightPosition="absolute"
            tagFlightHeight="83.9%"
            tagFlightMarginLeft={-24.5}
            tagFlightTop="0%"
            tagFlightBottom="16.1%"
            tagFlightLeft="50%"
            tagFlightMaxHeight="100%"
          />
        </View>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card2, styles.cardSpaceBlock]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("Webinar")}
      >
        <View style={styles.webinarParent}>
          <Text style={[styles.webinar, styles.webinarTypo]}>Webinar</Text>
          <Image
            style={[styles.tagHotel, styles.tagPosition]}
            contentFit="cover"
            source={require("../assets/tag--hotel1.png")}
          />
        </View>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card2, styles.cardSpaceBlock]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("OnlineCourse")}
      >
        <View style={styles.onlineCourseParent}>
          <Text style={[styles.onlineCourse, styles.internshipTypo]}>{` Online
Course`}</Text>
          <Image
            style={[styles.tagHotel1, styles.tagPosition]}
            contentFit="cover"
            source={require("../assets/tag--hotel2.png")}
          />
          <Image
            style={styles.icbaselineLaptopIcon}
            contentFit="cover"
            source={require("../assets/icbaselinelaptop.png")}
          />
        </View>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card4, styles.cardSpaceBlock]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("PaperPresentation")}
      >
        <View style={styles.paperPresentationParent}>
          <Text
            style={[styles.onlineCourse, styles.internshipTypo]}
          >{`      Paper 
Presentation`}</Text>
          <Image
            style={[styles.tagHotel2, styles.tagPosition]}
            contentFit="cover"
            source={require("../assets/tag--hotel3.png")}
          />
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector1.png")}
          />
        </View>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.card4, styles.cardSpaceBlock]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("ProjectPresentation")}
      >
        <View style={styles.projectPresentationParent}>
          <Text
            style={[styles.projectPresentation, styles.internshipTypo]}
          >{`     Project
Presentation`}</Text>
          <Image
            style={[styles.tagHotel2, styles.tagPosition]}
            contentFit="cover"
            source={require("../assets/tag--hotel4.png")}
          />
          <Image
            style={[styles.vectorIcon1, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector2.png")}
          />
        </View>
      </TouchableOpacity>
      <Pressable
        style={[styles.card4, styles.cardSpaceBlock]}
        onPress={() => navigation.navigate("TechnicalCompetition")}
      >
        <View style={styles.technicalCompetitionParent}>
          <Text
            style={[styles.technicalCompetition, styles.webinarTypo]}
          >{`  Technical
Competition`}</Text>
          <Image
            style={[styles.tagHotel4, styles.tagPosition]}
            contentFit="cover"
            source={require("../assets/tag--hotel5.png")}
          />
          <Image
            style={styles.octicontrophy24}
            contentFit="cover"
            source={require("../assets/octicontrophy24.png")}
          />
        </View>
      </Pressable>
    </ScrollView>
  );
});

const styles = StyleSheet.create({
  categoriesScrollViewContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  internshipTypo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
    left: 0,
    position: "absolute",
  },
  cardSpaceBlock: {
    marginLeft: 6,
    alignItems: "center",
  },
  webinarTypo: {
    left: "50%",
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
    position: "absolute",
  },
  tagPosition: {
    height: 48,
    top: 0,
    width: 48,
    left: "50%",
    position: "absolute",
  },
  vectorIconLayout: {
    width: "23.81%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  internship: {
    top: 65,
  },
  internshipParent: {
    width: 66,
    height: 82,
  },
  card1: {
    alignItems: "center",
    width: 75,
  },
  webinar: {
    marginLeft: -27.5,
    top: 66,
  },
  tagHotel: {
    marginLeft: -24,
  },
  webinarParent: {
    width: 55,
    height: 83,
  },
  card2: {
    width: 75,
    marginLeft: 6,
  },
  onlineCourse: {
    top: 57,
  },
  tagHotel1: {
    marginLeft: -23.25,
  },
  icbaselineLaptopIcon: {
    height: "20.88%",
    width: "43.75%",
    right: "27.6%",
    bottom: "64.84%",
    left: "28.65%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    top: "14.29%",
    position: "absolute",
  },
  onlineCourseParent: {
    height: 91,
    width: 48,
  },
  tagHotel2: {
    marginLeft: -23,
  },
  vectorIcon: {
    height: "21.98%",
    right: "38.1%",
    bottom: "63.74%",
    left: "38.1%",
    top: "14.29%",
    width: "23.81%",
  },
  paperPresentationParent: {
    width: 84,
    height: 91,
  },
  card4: {
    width: 90,
  },
  projectPresentation: {
    top: 56,
  },
  vectorIcon1: {
    height: "22.22%",
    top: "15.56%",
    right: "36.9%",
    bottom: "62.22%",
    left: "39.29%",
  },
  projectPresentationParent: {
    height: 90,
    width: 84,
  },
  technicalCompetition: {
    marginLeft: -40.5,
    top: 55,
  },
  tagHotel4: {
    marginLeft: -26,
  },
  octicontrophy24: {
    top: 11,
    left: 27,
    width: 24,
    height: 24,
    position: "absolute",
  },
  technicalCompetitionParent: {
    width: 81,
    height: 89,
  },
  categories: {
    alignSelf: "flex-start",
    width: "100%",
    marginTop: 30,
  },
});

export default FormWithButtonsAndCategories;
