import React, { useMemo, memo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1READIconyes = memo(
  ({
    actionButtonText,
    actionButtonLabel,
    property1READIconyesPosition,
    property1READIconyesBorderRadius,
    property1READIconyesBackgroundColor,
    property1READIconyesWidth,
    property1READIconyesHeight,
    property1READIconyesOverflow,
    readLineHeight,
    readFontFamily,
    onButtonPress,
  }) => {
    const property1READIconyesStyle = useMemo(() => {
      return {
        ...getStyleValue("position", property1READIconyesPosition),
        ...getStyleValue("borderRadius", property1READIconyesBorderRadius),
        ...getStyleValue(
          "backgroundColor",
          property1READIconyesBackgroundColor
        ),
        ...getStyleValue("width", property1READIconyesWidth),
        ...getStyleValue("height", property1READIconyesHeight),
        ...getStyleValue("overflow", property1READIconyesOverflow),
      };
    }, [
      property1READIconyesPosition,
      property1READIconyesBorderRadius,
      property1READIconyesBackgroundColor,
      property1READIconyesWidth,
      property1READIconyesHeight,
      property1READIconyesOverflow,
    ]);

    const readStyle = useMemo(() => {
      return {
        ...getStyleValue("lineHeight", readLineHeight),
        ...getStyleValue("fontFamily", readFontFamily),
      };
    }, [readLineHeight, readFontFamily]);

    return (
      <View
        style={[styles.property1readIconyes, property1READIconyesStyle]}
        onPress={onButtonPress}
      >
        <Text style={[styles.read, readStyle]}>{actionButtonText}</Text>
        <Image
          style={styles.vectorIcon}
          contentFit="cover"
          source={actionButtonLabel}
        />
      </View>
    );
  }
);

const styles = StyleSheet.create({
  read: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 14,
    fontFamily: FontFamily.pxRegular,
    color: Color.white,
    textAlign: "center",
  },
  vectorIcon: {
    width: 5,
    height: 9,
    marginLeft: 8,
  },
  property1readIconyes: {
    borderRadius: Border.br_base,
    backgroundColor: Color.mainGreen,
    shadowColor: "rgba(15, 39, 74, 0.1)",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 16,
    elevation: 16,
    shadowOpacity: 1,
    width: 96,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_5xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Property1READIconyes;
