import React, { memo } from "react";
import { View, Pressable, StyleSheet, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Padding, Border } from "../GlobalStyles";

const ProfilePhoto = memo(({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={styles.profilePhoto}>
      <View style={[styles.groupParent, styles.buttonFlexBox]}>
        <Image
          style={styles.groupIcon}
          contentFit="cover"
          source={require("../assets/group.png")}
        />
        <Pressable
          style={[styles.buttonWrapper, styles.buttonFlexBox]}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Profile" })
          }
        >
          <Pressable
            style={[styles.button, styles.buttonFlexBox]}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.uploadImage}>Upload Image</Text>
          </Pressable>
        </Pressable>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  buttonFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  groupIcon: {
    width: 100,
    height: 100,
  },
  uploadImage: {
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.gray50,
    textAlign: "center",
  },
  button: {
    backgroundColor: Color.darkorange,
    height: 57,
    flexDirection: "row",
    paddingHorizontal: Padding.p_11xl,
    paddingVertical: Padding.p_lg,
    justifyContent: "center",
    borderRadius: Border.br_3xs,
    alignSelf: "stretch",
  },
  buttonWrapper: {
    padding: Padding.p_3xs,
    marginTop: 19,
    justifyContent: "center",
  },
  groupParent: {
    flex: 1,
  },
  profilePhoto: {
    backgroundColor: Color.white,
    width: 265,
    height: 255,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_13xl,
    maxWidth: "100%",
    maxHeight: "100%",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: Border.br_3xs,
  },
});

export default ProfilePhoto;
