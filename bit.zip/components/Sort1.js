import React, { memo } from "react";
import { View, Pressable, Text, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const Sort1 = memo(({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={styles.sort1}>
      <Pressable
        style={styles.highToLow}
        onPress={() => navigation.navigate("SearchResult1")}
      >
        <Text style={[styles.highToLow1, styles.highTypo]}>High to Low</Text>
        <Image
          style={[styles.mdiarrowDownIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/mdiarrowdown.png")}
        />
      </Pressable>
      <Pressable
        style={styles.lowToHigh}
        onPress={() => navigation.navigate("SearchResult2")}
      >
        <Image
          style={[styles.tablerarrowUpIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerarrowup.png")}
        />
        <Text style={[styles.lowToHigh1, styles.highTypo]}>Low to High</Text>
      </Pressable>
    </View>
  );
});

const styles = StyleSheet.create({
  highTypo: {
    display: "flex",
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_lg,
    left: 25,
    top: 0,
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
  },
  iconLayout: {
    height: 24,
    width: 24,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  highToLow1: {
    width: 118,
    height: 32,
  },
  mdiarrowDownIcon: {
    top: 4,
  },
  highToLow: {
    width: 143,
    height: 32,
  },
  tablerarrowUpIcon: {
    top: 3,
  },
  lowToHigh1: {
    width: 114,
    height: 29,
  },
  lowToHigh: {
    width: 139,
    marginTop: 1,
    height: 29,
  },
  sort1: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.white,
    width: 191,
    height: 110,
    paddingHorizontal: 25,
    paddingVertical: Padding.p_xl,
    maxWidth: "100%",
    maxHeight: "100%",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
});

export default Sort1;
