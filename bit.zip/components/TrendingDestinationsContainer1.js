import React, { memo } from "react";
import {
  Text,
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const TrendingDestinationsContainer1 = memo(() => {
  const navigation = useNavigation();

  return (
    <View style={styles.trendingDestinations}>
      <View style={styles.trendingHeader}>
        <Text style={styles.trendingEvents}>Trending Events</Text>
        <Text style={styles.seeAll}>See all</Text>
      </View>
      <ScrollView
        style={styles.trendingCardsView}
        horizontal={true}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.trendingCardsViewContent}
      >
        <View style={styles.trandingCardsRow}>
          <TouchableOpacity
            style={styles.destinationCard}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("PaperPresentation")}
          >
            <Image
              style={styles.destinationIconLayout}
              contentFit="cover"
              source={require("../assets/destination-image.png")}
            />
            <View style={[styles.details, styles.detailsFlexBox]}>
              <View>
                <Text style={styles.dataconTypo}>Datacon</Text>
                <Text style={styles.onlineCourseTypo}>Paper Presentation</Text>
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.destinationCard1, styles.destinationCardShadowBox]}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("TechnicalCompetition")}
          >
            <Image
              style={[
                styles.destinationImageIcon1,
                styles.destinationIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/destination-image1.png")}
            />
            <View style={[styles.details, styles.detailsFlexBox]}>
              <View>
                <Text style={[styles.techPalooza, styles.dataconTypo]}>
                  Tech-Palooza
                </Text>
                <Text style={styles.onlineCourseTypo}>
                  Technical Competition
                </Text>
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.destinationCardShadowBox}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("Webinar")}
          >
            <Image
              style={[
                styles.destinationImageIcon1,
                styles.destinationIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/destination-image2.png")}
            />
            <View style={[styles.details2, styles.detailsFlexBox]}>
              <View>
                <Text style={styles.dataconTypo}>Prayukthi</Text>
                <Text style={styles.onlineCourseTypo}>Webinar</Text>
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.destinationCard11, styles.destinationCardShadowBox]}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("ProjectPresentation")}
          >
            <Image
              style={[
                styles.destinationImageIcon1,
                styles.destinationIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/destination-image3.png")}
            />
            <View style={[styles.details3, styles.detailsFlexBox]}>
              <View>
                <Text style={styles.techJamboree}>Tech-jamboree</Text>
                <Text style={styles.onlineCourseTypo}>
                  Project Presentation
                </Text>
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.destinationCard21, styles.destinationCardShadowBox]}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("Internship")}
          >
            <Image
              style={[
                styles.destinationImageIcon1,
                styles.destinationIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/destination-image4.png")}
            />
            <View style={[styles.details4, styles.detailsFlexBox]}>
              <View>
                <Text
                  style={[styles.accenture, styles.dataconTypo]}
                >{`Accenture `}</Text>
                <Text style={styles.onlineCourseTypo}>Internship</Text>
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.destinationCard3, styles.destinationCardShadowBox]}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("OnlineCourse")}
          >
            <Image
              style={[
                styles.destinationImageIcon1,
                styles.destinationIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/destination-image5.png")}
            />
            <View style={[styles.details5, styles.detailsFlexBox]}>
              <View>
                <Text style={[styles.webDevelopment, styles.dataconTypo]}>
                  Web Development
                </Text>
                <Text style={[styles.onlineCourse, styles.onlineCourseTypo]}>
                  Online course
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
});

const styles = StyleSheet.create({
  trendingCardsViewContent: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  detailsFlexBox: {
    marginTop: 10,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  destinationCardShadowBox: {
    marginLeft: 10,
    padding: Padding.p_3xs,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xs,
  },
  destinationIconLayout: {
    height: 90,
    width: 131,
  },
  dataconTypo: {
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
    color: Color.black,
  },
  onlineCourseTypo: {
    marginTop: 1,
    color: Color.lightslategray,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.interRegular,
    textAlign: "left",
  },
  trendingEvents: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    lineHeight: 24,
  },
  seeAll: {
    color: Color.cornflowerblue,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
  },
  trendingHeader: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  details: {
    alignSelf: "stretch",
  },
  destinationCard: {
    padding: Padding.p_3xs,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    backgroundColor: Color.white,
    borderRadius: Border.br_5xs,
    width: 151,
  },
  destinationImageIcon1: {
    borderRadius: Border.br_11xs,
  },
  techPalooza: {
    lineHeight: 24,
    fontWeight: "600",
  },
  destinationCard1: {
    width: 151,
    marginLeft: 10,
  },
  details2: {
    width: 78,
  },
  techJamboree: {
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  details3: {
    width: 124,
  },
  destinationCard11: {
    width: 151,
    marginLeft: 10,
  },
  accenture: {
    width: 102,
  },
  details4: {
    width: 105,
  },
  destinationCard21: {
    width: 151,
    marginLeft: 10,
  },
  webDevelopment: {
    width: 129,
  },
  onlineCourse: {
    width: 90,
  },
  details5: {
    width: 131,
    marginTop: 10,
    alignItems: "center",
  },
  destinationCard3: {
    width: 151,
    marginLeft: 10,
  },
  trandingCardsRow: {
    flexDirection: "row",
  },
  trendingCardsView: {
    width: "100%",
    marginTop: 14,
    alignSelf: "stretch",
  },
  trendingDestinations: {
    marginTop: 30,
    alignSelf: "stretch",
  },
});

export default TrendingDestinationsContainer1;
