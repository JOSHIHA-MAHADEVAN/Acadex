import React, { useMemo, memo } from "react";
import { Image } from "expo-image";
import { StyleSheet } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const TagFlight = memo(
  ({
    tagFlightPosition,
    tagFlightHeight,
    tagFlightMarginLeft,
    tagFlightTop,
    tagFlightBottom,
    tagFlightLeft,
    tagFlightMaxHeight,
  }) => {
    const tagFlightStyle = useMemo(() => {
      return {
        ...getStyleValue("position", tagFlightPosition),
        ...getStyleValue("height", tagFlightHeight),
        ...getStyleValue("marginLeft", tagFlightMarginLeft),
        ...getStyleValue("top", tagFlightTop),
        ...getStyleValue("bottom", tagFlightBottom),
        ...getStyleValue("left", tagFlightLeft),
        ...getStyleValue("maxHeight", tagFlightMaxHeight),
      };
    }, [
      tagFlightPosition,
      tagFlightHeight,
      tagFlightMarginLeft,
      tagFlightTop,
      tagFlightBottom,
      tagFlightLeft,
      tagFlightMaxHeight,
    ]);

    return (
      <Image
        style={[styles.tagFlight, tagFlightStyle]}
        contentFit="cover"
        source={require("../assets/tag--flight.png")}
      />
    );
  }
);

const styles = StyleSheet.create({
  tagFlight: {
    width: 48,
    height: 48,
  },
});

export default TagFlight;
