import React, { memo } from "react";
import { View, StyleSheet, Pressable, Text } from "react-native";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Padding, Border } from "../GlobalStyles";

const Passwod = memo(({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.passwod, styles.passwodFlexBox]}>
      <View style={[styles.outlinedtextOnlyNoIconParent, styles.buttonFlexBox]}>
        <TextInput
          style={styles.outlinedtextIconLayout}
          label="Password"
          placeholder="Enter Password"
          mode="outlined"
          right={<TextInput.Icon style={{ marginTop: "50%" }} name="lock" />}
          placeholderTextColor="#191919"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#9eaab6" },
          }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconLayout,
          ]}
          label="Confirm"
          placeholder="Confirm Password"
          mode="outlined"
          right={
            <TextInput.Icon style={{ marginTop: "50%" }} name="lock-check" />
          }
          placeholderTextColor="#191919"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#9eaab6" },
          }}
        />
        <Pressable
          style={[styles.buttonWrapper, styles.passwodFlexBox]}
          onPress={() => navigation.goBack()}
        >
          <Pressable
            style={[styles.button, styles.buttonFlexBox]}
            onPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Profile" })
            }
          >
            <Text style={styles.confirm}>Confirm</Text>
          </Pressable>
        </Pressable>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  passwodFlexBox: {
    alignItems: "center",
    justifyContent: "center",
  },
  buttonFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 11,
  },
  confirm: {
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.gray50,
    textAlign: "center",
  },
  button: {
    backgroundColor: Color.darkorange,
    height: 57,
    flexDirection: "row",
    paddingHorizontal: Padding.p_11xl,
    paddingVertical: Padding.p_lg,
    justifyContent: "center",
    borderRadius: Border.br_3xs,
  },
  buttonWrapper: {
    marginTop: 11,
    justifyContent: "center",
  },
  outlinedtextOnlyNoIconParent: {
    flex: 1,
  },
  passwod: {
    backgroundColor: Color.white,
    width: 265,
    height: 243,
    overflow: "hidden",
    paddingHorizontal: 24,
    paddingVertical: 26,
    maxWidth: "100%",
    maxHeight: "100%",
    justifyContent: "center",
    borderRadius: Border.br_3xs,
  },
});

export default Passwod;
