import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const MenuItem2 = memo(({ style }) => {
  return (
    <View style={[styles.menuItem, style]}>
      <Image
        style={styles.ionmailOutlineIcon}
        contentFit="cover"
        source={require("../assets/ionmailoutline.png")}
      />
      <Text style={styles.getHelp}>Get Help</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  ionmailOutlineIcon: {
    width: 24,
    overflow: "hidden",
    height: 24,
  },
  getHelp: {
    fontSize: FontSize.size_base,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.black,
    textAlign: "left",
    marginLeft: 16,
  },
  menuItem: {
    width: 169,
    flexDirection: "row",
    height: 24,
  },
});

export default MenuItem2;
