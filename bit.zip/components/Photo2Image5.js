import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Photo2Image5 = memo(({ style }) => {
  return (
    <Image
      style={[styles.photo2Icon, style]}
      contentFit="cover"
      source={require("../assets/photo40.png")}
    />
  );
});

const styles = StyleSheet.create({
  photo2Icon: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 90,
  },
});

export default Photo2Image5;
