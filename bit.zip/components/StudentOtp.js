import React, { memo } from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Padding, Border } from "../GlobalStyles";

const StudentOtp = memo(({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.studentotp, styles.studentotpLayout]}>
      <View style={[styles.enterOtpParent, styles.frameChildFlexBox]}>
        <Text style={styles.enterOtp}>Enter OTP</Text>
        <View style={[styles.frameParent, styles.buttonFlexBox]}>
          <View style={styles.parent}>
            <Text style={[styles.text, styles.textTypo]} numberOfLines={1}>
              0
            </Text>
            <Text style={[styles.text1, styles.textTypo]} numberOfLines={1}>
              0
            </Text>
            <Text style={[styles.text2, styles.textTypo]} numberOfLines={1}>
              0
            </Text>
            <Text style={[styles.text3, styles.textTypo]} numberOfLines={1}>
              0
            </Text>
          </View>
          <Image
            style={[styles.frameChild, styles.frameChildFlexBox]}
            contentFit="cover"
            source={require("../assets/line-1.png")}
          />
        </View>
        <Pressable
          style={[styles.button, styles.buttonFlexBox]}
          onPress={() => navigation.navigate("StudentLoginPersonalForm")}
        >
          <Text style={styles.confirm}>Confirm</Text>
        </Pressable>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  studentotpLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  frameChildFlexBox: {
    flex: 1,
    alignSelf: "stretch",
  },
  buttonFlexBox: {
    marginTop: 46,
    alignSelf: "stretch",
    justifyContent: "center",
    alignItems: "center",
  },
  textTypo: {
    opacity: 0.4,
    height: 34,
    width: 28,
    top: 1,
    position: "absolute",
    display: "flex",
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_lg,
    justifyContent: "center",
    alignItems: "center",
  },
  enterOtp: {
    width: 195,
    height: 54,
    display: "flex",
    color: Color.black,
    textAlign: "center",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_lg,
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    left: 59,
  },
  text1: {
    left: 126,
  },
  text2: {
    left: 193,
  },
  text3: {
    left: 0,
  },
  parent: {
    width: 224,
    height: 35,
  },
  frameChild: {
    width: "100%",
    marginTop: 10,
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    alignSelf: "stretch",
  },
  frameParent: {
    height: 20,
    padding: Padding.p_3xs,
  },
  confirm: {
    color: Color.gray50,
    textAlign: "center",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_lg,
  },
  button: {
    backgroundColor: Color.cornflowerblue,
    height: 57,
    flexDirection: "row",
    paddingHorizontal: Padding.p_11xl,
    paddingVertical: Padding.p_lg,
    borderRadius: Border.br_3xs,
    marginTop: 46,
  },
  enterOtpParent: {
    paddingHorizontal: 0,
    paddingVertical: 1,
    alignItems: "center",
    alignSelf: "stretch",
  },
  studentotp: {
    backgroundColor: Color.white,
    width: 266,
    height: 295,
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_13xl,
    justifyContent: "center",
    maxHeight: "100%",
    maxWidth: "100%",
    alignItems: "center",
    overflow: "hidden",
    borderRadius: Border.br_3xs,
  },
});

export default StudentOtp;
