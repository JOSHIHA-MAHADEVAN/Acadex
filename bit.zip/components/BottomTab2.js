import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const BottomTab2 = memo(({ style }) => {
  return (
    <View style={[styles.bottomTab, style]}>
      <Image
        style={styles.phcertificateFillIcon}
        contentFit="cover"
        source={require("../assets/phcertificatefill.png")}
      />
      <Text style={styles.certificate}>Certificate</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  phcertificateFillIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  certificate: {
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.robotoRegular,
    color: Color.lightslategray,
    textAlign: "center",
    marginTop: 14,
  },
  bottomTab: {
    width: 61,
    alignItems: "center",
  },
});

export default BottomTab2;
