import React, { memo } from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Pressable,
  Text,
  TouchableOpacity,
} from "react-native";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const Login = memo(({ style }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.login, style]}>
      <View style={styles.form}>
        <TextInput
          style={styles.outlinedtextIconLayout}
          label="Email"
          placeholder="Enter email"
          mode="outlined"
          right={
            <TextInput.Icon
              style={{ marginTop: "50%" }}
              name="email-edit-outline"
            />
          }
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{ colors: { text: "#000" } }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconLayout,
          ]}
          label="Password"
          placeholder="Enter Password"
          mode="outlined"
          right={<TextInput.Icon style={{ marginTop: "50%" }} name="lock" />}
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{ colors: { text: "#000" } }}
        />
      </View>
      <TouchableOpacity
        style={[styles.buttonPrimary, styles.doctorFlexBox]}
        activeOpacity={0.2}
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "Student" })
        }
      >
        <Text style={styles.viewDetails}>Login</Text>
      </TouchableOpacity>
      <View style={styles.doctorWrapper}>
        <View style={[styles.doctor, styles.doctorFlexBox]}>
          <Text style={[styles.areYouA, styles.areYouATypo]}>
            Are you a Faculty
          </Text>
          <Text style={[styles.signinHere, styles.areYouATypo]}>
            Signin here
          </Text>
        </View>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  doctorFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  areYouATypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xs,
    textAlign: "center",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 18,
  },
  form: {
    alignSelf: "stretch",
  },
  viewDetails: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.white,
    width: 120,
    textAlign: "center",
  },
  buttonPrimary: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.orange_200,
    width: 313,
    paddingHorizontal: Padding.p_xl,
    marginTop: 25,
    paddingVertical: Padding.p_3xs,
  },
  areYouA: {
    color: Color.gray_100,
    width: 104,
  },
  signinHere: {
    color: Color.darkorange,
    width: 69,
    marginLeft: 5,
  },
  doctor: {
    width: 175,
  },
  doctorWrapper: {
    marginTop: 25,
  },
  login: {
    flex: 1,
    backgroundColor: Color.white,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    alignSelf: "stretch",
  },
});

export default Login;
