import React, { memo } from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Pressable,
  Text,
  TouchableOpacity,
} from "react-native";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Offline = memo(({ style }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.offline, style, styles.outlinedtextIconFlexBox]}>
      <View style={styles.form}>
        <TextInput
          style={styles.outlinedtextIconFlexBox}
          label="Event"
          placeholder="Enter Event"
          mode="outlined"
          right={
            <TextInput.Icon
              style={{ marginTop: "50%" }}
              name="calendar-check-outline"
            />
          }
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#000" },
          }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconFlexBox,
          ]}
          label="Place"
          placeholder="Enter Place"
          mode="outlined"
          right={
            <TextInput.Icon
              style={{ marginTop: "50%" }}
              name="map-marker-left"
            />
          }
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#000" },
          }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconFlexBox,
          ]}
          label="Team Members"
          placeholder="Enter"
          mode="outlined"
          right={
            <TextInput.Icon
              style={{ marginTop: "50%" }}
              name="account-multiple-plus"
            />
          }
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#000" },
          }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconFlexBox,
          ]}
          label="Fee"
          placeholder="Enter"
          mode="outlined"
          right={
            <TextInput.Icon style={{ marginTop: "50%" }} name="currency-usd" />
          }
          placeholderTextColor="#9eaab6"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#000" },
          }}
        />
      </View>
      <TouchableOpacity
        style={styles.buttonPrimary}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("SearchResult1")}
      >
        <Text style={styles.viewDetails}>Search</Text>
      </TouchableOpacity>
    </View>
  );
});

const styles = StyleSheet.create({
  outlinedtextIconFlexBox: {
    flex: 1,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 18,
  },
  form: {
    height: 278,
    alignSelf: "stretch",
  },
  viewDetails: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.white,
    textAlign: "center",
    width: 120,
  },
  buttonPrimary: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.orange_200,
    width: 313,
    flexDirection: "row",
    paddingHorizontal: Padding.p_xl,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 13,
    paddingVertical: Padding.p_3xs,
  },
  offline: {
    backgroundColor: Color.white,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
  },
});

export default Offline;
