import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Image12 = memo(({ style }) => {
  return (
    <Image
      style={[styles.image12Icon, style]}
      contentFit="cover"
      source={require("../assets/image-12.png")}
    />
  );
});

const styles = StyleSheet.create({
  image12Icon: {
    borderRadius: Border.br_9xs,
    width: 104,
    height: 71,
  },
});

export default Image12;
