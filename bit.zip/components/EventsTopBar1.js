import React, { useState, useCallback, memo } from "react";
import {
  View,
  StyleProp,
  ViewStyle,
  Pressable,
  StyleSheet,
  Text,
  Modal,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Sort1 from "./Sort1";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const EventsTopBar1 = memo(({ style }) => {
  const navigation = useNavigation();
  const [iconKebabVisible, setIconKebabVisible] = useState(false);

  const openIconKebab = useCallback(() => {
    setIconKebabVisible(true);
  }, []);

  const closeIconKebab = useCallback(() => {
    setIconKebabVisible(false);
  }, []);

  return (
    <>
      <SafeAreaView style={[styles.eventsTopBar, style]}>
        <View style={styles.view}>
          <Pressable
            style={styles.iconLayout}
            onPress={() => navigation.goBack()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/icon--back.png")}
            />
          </Pressable>
          <View style={styles.innerFlexBox}>
            <View style={[styles.eventsWrapper, styles.innerFlexBox]}>
              <Text style={styles.events}>Events</Text>
            </View>
          </View>
          <Pressable
            style={[styles.iconKebab, styles.iconLayout]}
            onPress={openIconKebab}
          >
            <View style={styles.ellipseParent}>
              <Image
                style={styles.frameLayout}
                contentFit="cover"
                source={require("../assets/ellipse-1.png")}
              />
              <Image
                style={[styles.frameItem, styles.frameLayout]}
                contentFit="cover"
                source={require("../assets/ellipse-2.png")}
              />
              <Image
                style={[styles.frameItem, styles.frameLayout]}
                contentFit="cover"
                source={require("../assets/ellipse-3.png")}
              />
            </View>
          </Pressable>
        </View>
      </SafeAreaView>

      <Modal animationType="fade" transparent visible={iconKebabVisible}>
        <View style={styles.iconKebabOverlay}>
          <Pressable style={styles.iconKebabBg} onPress={closeIconKebab} />
          <Sort1 onClose={closeIconKebab} />
        </View>
      </Modal>
    </>
  );
});

const styles = StyleSheet.create({
  eventsTopBar: {
    backgroundColor: Color.white,
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  events: {
    fontSize: FontSize.size_base,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.black,
    textAlign: "left",
  },
  eventsWrapper: {
    flexDirection: "row",
    justifyContent: "center",
  },
  iconKebabOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  iconKebabBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  frameItem: {
    marginTop: 4,
  },
  ellipseParent: {
    position: "absolute",
    top: 5,
    left: 14,
  },
  iconKebab: {
    overflow: "hidden",
  },
  view: {
    alignSelf: "stretch",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_sm,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
});

export default EventsTopBar1;
