import React, { memo } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Text,
  TouchableOpacity,
} from "react-native";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Padding, Border } from "../GlobalStyles";

const Description = memo(({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.description, styles.descriptionFlexBox]}>
      <View style={[styles.outlinedtextOnlyNoIconParent, styles.buttonFlexBox]}>
        <TextInput
          style={styles.outlinedtextIconLayout}
          label="Headline"
          placeholder="Enter the headline"
          mode="outlined"
          right={
            <TextInput.Icon style={{ marginTop: "50%" }} name="note-multiple" />
          }
          placeholderTextColor="#191919"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#9eaab6" },
          }}
        />
        <TextInput
          style={[
            styles.outlinedtextOnlyNoIcon1,
            styles.outlinedtextIconLayout,
          ]}
          label="Description"
          placeholder="Enter the description"
          mode="outlined"
          right={
            <TextInput.Icon
              style={{ marginTop: "50%" }}
              name="note-multiple-outline"
            />
          }
          placeholderTextColor="#191919"
          outlineColor="#9eaab6"
          activeOutlineColor="#3b7beb"
          theme={{
            fonts: { regular: { fontFamily: "Roboto", fontWeight: "Regular" } },
            colors: { text: "#9eaab6" },
          }}
        />
        <Pressable
          style={[styles.buttonWrapper, styles.descriptionFlexBox]}
          onPress={() => navigation.goBack()}
        >
          <TouchableOpacity
            style={[styles.button, styles.buttonFlexBox]}
            activeOpacity={0.2}
            onPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Profile" })
            }
          >
            <Text style={styles.edit}>Edit</Text>
          </TouchableOpacity>
        </Pressable>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  descriptionFlexBox: {
    alignItems: "center",
    justifyContent: "center",
  },
  buttonFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 11,
  },
  edit: {
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.gray50,
    textAlign: "center",
  },
  button: {
    backgroundColor: Color.darkorange,
    height: 57,
    flexDirection: "row",
    paddingHorizontal: Padding.p_11xl,
    paddingVertical: Padding.p_lg,
    justifyContent: "center",
    borderRadius: Border.br_3xs,
  },
  buttonWrapper: {
    marginTop: 11,
    justifyContent: "center",
  },
  outlinedtextOnlyNoIconParent: {
    height: 198,
  },
  description: {
    backgroundColor: Color.white,
    width: 265,
    height: 230,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_13xl,
    maxWidth: "100%",
    maxHeight: "100%",
    justifyContent: "center",
    borderRadius: Border.br_3xs,
  },
});

export default Description;
