import React, { useState, useCallback, memo } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import Sort1 from "./Sort1";
import FormSection from "./FormSection";
import { FontFamily, Color, FontSize, Padding, Border } from "../GlobalStyles";

const SearchTwoWay = memo(() => {
  const navigation = useNavigation();
  const [iconKebabVisible, setIconKebabVisible] = useState(false);

  const openIconKebab = useCallback(() => {
    setIconKebabVisible(true);
  }, []);

  const closeIconKebab = useCallback(() => {
    setIconKebabVisible(false);
  }, []);

  return (
    <>
      <View style={styles.searchTwoWay}>
        <View style={styles.group4}>
          <Pressable
            style={styles.iconLayout}
            onPress={() => navigation.goBack()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/icon--back.png")}
            />
          </Pressable>
          <Text style={[styles.searchEvents, styles.viewDetailsTypo]}>
            Search Events
          </Text>
          <Pressable
            style={[styles.iconKebab, styles.iconLayout]}
            onPress={openIconKebab}
          >
            <View style={styles.ellipseParent}>
              <Image
                style={styles.frameLayout}
                contentFit="cover"
                source={require("../assets/ellipse-1.png")}
              />
              <Image
                style={[styles.frameItem, styles.frameLayout]}
                contentFit="cover"
                source={require("../assets/ellipse-2.png")}
              />
              <Image
                style={[styles.frameItem, styles.frameLayout]}
                contentFit="cover"
                source={require("../assets/ellipse-3.png")}
              />
            </View>
          </Pressable>
        </View>
        <ScrollView
          style={[styles.event1Parent, styles.outlinedtextIconFlexBox]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.frameScrollViewContent}
        >
          <View style={styles.event1}>
            <View style={styles.second} />
          </View>
          <FormSection
            dimensions={require("../assets/offer-image2.png")}
            carDimensions={require("../assets/offer-image3.png")}
            propMarginTop={20}
            onOfferCardPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
            }
            onOfferCardPress1={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
            }
          />
        </ScrollView>
      </View>

      <Modal animationType="fade" transparent visible={iconKebabVisible}>
        <View style={styles.iconKebabOverlay}>
          <Pressable style={styles.iconKebabBg} onPress={closeIconKebab} />
          <Sort1 onClose={closeIconKebab} />
        </View>
      </Modal>
    </>
  );
});

const styles = StyleSheet.create({
  frameScrollViewContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewDetailsTypo: {
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  outlinedtextIconFlexBox: {
    flex: 1,
    alignSelf: "stretch",
  },
  online2FlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  offlineTypo: {
    color: Color.white,
    textAlign: "center",
    lineHeight: 24,
    fontSize: FontSize.pxRegular_size,
  },
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  searchEvents: {
    fontSize: FontSize.size_base,
    color: Color.black,
    textAlign: "left",
  },
  iconKebabOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  iconKebabBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  frameItem: {
    marginTop: 4,
  },
  ellipseParent: {
    position: "absolute",
    top: 5,
    left: 14,
  },
  iconKebab: {
    overflow: "hidden",
  },
  group4: {
    width: 375,
    paddingVertical: Padding.p_sm,
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Padding.p_base,
    flexDirection: "row",
    backgroundColor: Color.white,
  },
  second: {
    backgroundColor: Color.ghostwhite,
    padding: Padding.p_9xs,
    borderRadius: Border.br_13xl,
    alignSelf: "stretch",
    flexDirection: "row",
  },
  event1: {
    borderRadius: Border.br_xs,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    width: 341,
    height: 467,
    padding: Padding.p_sm,
    backgroundColor: Color.white,
  },
  event1Parent: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
  searchTwoWay: {
    width: 371,
    height: 684,
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
});

export default SearchTwoWay;
