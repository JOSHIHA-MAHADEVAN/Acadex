import React, { memo } from "react";
import { View, StyleProp, ViewStyle, Text, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const Group4 = memo(({ style }) => {
  return (
    <SafeAreaView style={[styles.group4, style]}>
      <View style={[styles.view, styles.viewFlexBox]}>
        <View style={[styles.studentWrapper, styles.viewFlexBox]}>
          <Text style={styles.student}>Student</Text>
        </View>
      </View>
    </SafeAreaView>
  );
});

const styles = StyleSheet.create({
  group4: {
    backgroundColor: Color.white,
  },
  viewFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  student: {
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.black,
    textAlign: "left",
  },
  studentWrapper: {
    width: 77,
    height: 24,
  },
  view: {
    width: 375,
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_sm,
  },
});

export default Group4;
