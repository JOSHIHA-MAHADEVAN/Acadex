import React, { useState, memo } from "react";
import MenuItem5 from "./MenuItem5";
import MenuItem4 from "./MenuItem4";
import MenuItem3 from "./MenuItem3";
import MenuItem2 from "./MenuItem2";
import MenuItem1 from "./MenuItem1";
import MenuItem from "./MenuItem";
import { Image } from "expo-image";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import { Badge } from "react-native-paper";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const DrawerMenu = memo(({ state, navigation }) => {
  const [drawerItemsNormal] = useState([
    <MenuItem5 />,
    <MenuItem4 />,
    <MenuItem3 />,
    <MenuItem2 />,
    <MenuItem1 />,
    <MenuItem />,
  ]);
  const [drawerItemsActive] = useState([
    <MenuItem5 />,
    <MenuItem4 />,
    <MenuItem3 />,
    <MenuItem2 />,
    <MenuItem1 />,
    <MenuItem />,
  ]);
  const stateIndex = !state ? 0 : state.index - 1;

  return (
    <View style={styles.drawerMenu}>
      <View style={styles.menu}>
        <View style={styles.profile}>
          <View style={styles.group3Wrapper}>
            <Image
              style={styles.group3Icon}
              contentFit="cover"
              source={require("../assets/group31.png")}
            />
          </View>
          <View style={styles.helloParent}>
            <Text style={styles.hello}>Hello</Text>
            <Text style={styles.lathika}>Lathika</Text>
          </View>
        </View>
        <View style={styles.menuChild} />
        <View style={styles.drawerMenuItems}>
          {stateIndex === 0 ? drawerItemsActive[0] : drawerItemsNormal[0]}
          {stateIndex === 1 ? drawerItemsActive[1] : drawerItemsNormal[1]}
          {stateIndex === 2 ? drawerItemsActive[2] : drawerItemsNormal[2]}
          {stateIndex === 3 ? drawerItemsActive[3] : drawerItemsNormal[3]}
          {stateIndex === 4 ? drawerItemsActive[4] : drawerItemsNormal[4]}
          {stateIndex === 5 ? drawerItemsActive[5] : drawerItemsNormal[5]}
        </View>
      </View>
      <View style={styles.group3Wrapper}>
        <Text style={[styles.acadex, styles.acadexLayout]}>Acadex</Text>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  menuItemLayout: {
    height: 24,
    flexDirection: "row",
  },
  acadexLayout: {
    lineHeight: 24,
    textAlign: "left",
  },
  iconlylightprofileLayout: {
    width: 24,
    height: 24,
  },
  group3Icon: {
    width: 49,
    height: 49,
  },
  group3Wrapper: {
    flexDirection: "row",
  },
  hello: {
    fontSize: FontSize.size_xs,
    lineHeight: 18,
    fontFamily: FontFamily.robotoRegular,
    textAlign: "left",
    color: Color.lightslategray,
  },
  lathika: {
    fontSize: FontSize.size_xl,
    lineHeight: 30,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    color: Color.black,
    textAlign: "left",
  },
  helloParent: {
    marginLeft: 12,
  },
  profile: {
    alignItems: "center",
    flexDirection: "row",
  },
  menuChild: {
    borderStyle: "solid",
    borderColor: "#e6e9f0",
    borderTopWidth: 1,
    height: 1,
    marginTop: 20,
    alignSelf: "stretch",
  },
  drawerMenuItems: {
    height: 284,
    marginTop: 20,
    justifyContent: "space-between",
  },
  menu: {
    alignSelf: "stretch",
  },
  acadex: {
    fontSize: FontSize.pxRegular_size,
    fontFamily: FontFamily.jotiOneRegular,
    color: Color.lightslategray,
  },
  drawerMenu: {
    backgroundColor: Color.white,
    width: 316,
    height: 968,
    paddingHorizontal: Padding.p_11xl,
    paddingVertical: Padding.p_xl,
    justifyContent: "space-between",
  },
});

export default DrawerMenu;
