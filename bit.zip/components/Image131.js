import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Image131 = memo(({ style }) => {
  return (
    <Image
      style={[styles.image13Icon, style]}
      contentFit="cover"
      source={require("../assets/image-131.png")}
    />
  );
});

const styles = StyleSheet.create({
  image13Icon: {
    borderRadius: Border.br_9xs,
    width: 104,
    height: 72,
  },
});

export default Image131;
