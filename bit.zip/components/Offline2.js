import React, { memo } from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Offline2 = memo(({ style }) => {
  return (
    <View style={[styles.offline2, style]}>
      <Text style={styles.offline}>Offline</Text>
    </View>
  );
});

const styles = StyleSheet.create({
  offline: {
    fontSize: FontSize.pxRegular_size,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: Color.white,
    textAlign: "center",
  },
  offline2: {
    borderRadius: Border.br_13xl,
    backgroundColor: Color.cornflowerblue,
    width: 153,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_7xs,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Offline2;
