import React, { memo } from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const Image102 = memo(({ style }) => {
  return (
    <Image
      style={[styles.image10Icon, style]}
      contentFit="cover"
      source={require("../assets/image-102.png")}
    />
  );
});

const styles = StyleSheet.create({
  image10Icon: {
    borderRadius: Border.br_9xs,
    width: 104,
    height: 72,
  },
});

export default Image102;
