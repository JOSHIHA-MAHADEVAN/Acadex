import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import Carousel from "react-native-reanimated-carousel";
import Photo1Image1 from "../components/Photo1Image1";
import Photo2Image1 from "../components/Photo2Image1";
import Photo3Image1 from "../components/Photo3Image1";
import Photo4Image1 from "../components/Photo4Image1";
import Photo5Image1 from "../components/Photo5Image1";
import Photo6Image1 from "../components/Photo6Image1";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const TechnicalCompetition = () => {
  const [photosRowItems, setPhotosRowItems] = useState([
    <Photo1Image1 />,
    <Photo2Image1 />,
    <Photo3Image1 />,
    <Photo4Image1 />,
    <Photo5Image1 />,
    <Photo6Image1 />,
  ]);

  return (
    <View style={styles.technicalCompetition}>
      <ScrollView
        style={styles.searchResultsBody}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.searchResultsBodyContent}
      >
        <View style={[styles.listHeader, styles.viewFlexBox]}>
          <Text style={[styles.resultsFound, styles.resultsFoundClr]}>
            results found
          </Text>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/sort-01.png")}
          />
        </View>
        <View style={styles.listItems}>
          <View style={styles.technicalCompetition1}>
            <View style={styles.view1}>
              <Image
                style={styles.line3Icon}
                contentFit="cover"
                source={require("../assets/line3.png")}
              />
              <View style={styles.frameParent}>
                <View style={styles.viewFlexBox}>
                  <View
                    style={[
                      styles.technicalCompetitionWrapper,
                      styles.buttonPrimaryFlexBox,
                    ]}
                  >
                    <Text
                      style={[
                        styles.technicalCompetition2,
                        styles.viewDetailsFlexBox,
                      ]}
                    >
                      Technical Competition
                    </Text>
                  </View>
                  <Image
                    style={styles.iconHeart}
                    contentFit="cover"
                    source={require("../assets/icon--heart6.png")}
                  />
                </View>
                <Text
                  style={[
                    styles.techPaloozaTechnicalCompetiContainer,
                    styles.buttonPrimarySpaceBlock,
                  ]}
                >
                  <Text style={styles.techPaloozaTypo}>{`Tech-Palooza `}</Text>
                  <Text style={styles.technicalCompetitionEvent}>
                    Technical Competition event conducted by KCT
                  </Text>
                </Text>
                <View
                  style={[
                    styles.photosRowParent,
                    styles.buttonPrimarySpaceBlock,
                  ]}
                >
                  <View style={styles.photosRow}>
                    <Carousel
                      style={styles.carousel}
                      width={130}
                      mode="normal"
                      autoPlay={true}
                      loop={true}
                      data={photosRowItems}
                      renderItem={({ item }) => item}
                    />
                  </View>
                  <View style={styles.technicalCompetitionConducteWrapper}>
                    <Text
                      style={[
                        styles.technicalCompetitionConducte,
                        styles.resultsFoundClr,
                      ]}
                    >{`Technical Competition conducted by the department ECE!
Date:Oct 1,2023
Time:10.00am-12:30pm`}</Text>
                  </View>
                  <Image
                    style={styles.frameChild1}
                    contentFit="cover"
                    source={require("../assets/vector-1.png")}
                  />
                </View>
                <View
                  style={[styles.buttonPrimary, styles.buttonPrimarySpaceBlock]}
                >
                  <Text style={[styles.viewDetails, styles.viewDetailsFlexBox]}>
                    Register
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  eventsFlexBox: {
    textAlign: "left",
    color: Color.black,
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  resultsFoundClr: {
    color: Color.lightslategray,
    textAlign: "left",
  },
  buttonPrimaryFlexBox: {
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  viewDetailsFlexBox: {
    textAlign: "center",
    color: Color.white,
  },
  buttonPrimarySpaceBlock: {
    marginTop: 10,
    alignSelf: "stretch",
  },
  resultsFound: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
  },
  vectorIcon: {
    width: 17,
    height: 15,
  },
  listHeader: {
    paddingBottom: Padding.p_2xs,
  },
  line3Icon: {
    maxWidth: "100%",
    height: 1,
    overflow: "hidden",
    alignSelf: "stretch",
    width: "100%",
  },
  technicalCompetition2: {
    fontSize: FontSize.size_smi,
    textTransform: "uppercase",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
  },
  technicalCompetitionWrapper: {
    backgroundColor: Color.mediumaquamarine,
    paddingHorizontal: Padding.p_6xs,
    paddingVertical: Padding.p_11xs,
  },
  iconHeart: {
    width: 16,
    height: 16,
    overflow: "hidden",
  },
  techPaloozaTypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  technicalCompetitionEvent: {
    fontFamily: FontFamily.robotoRegular,
  },
  techPaloozaTechnicalCompetiContainer: {
    fontSize: FontSize.size_lg,
    lineHeight: 24,
    textAlign: "left",
    color: Color.black,
  },
  carousel: {
    width: 120,
    height: 90,
  },
  photosRow: {
    height: 90,
    width: 120,
  },
  technicalCompetitionConducte: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.robotoRegular,
    lineHeight: 18,
    alignSelf: "stretch",
  },
  technicalCompetitionConducteWrapper: {
    width: 156,
    marginLeft: 16,
  },
  frameChild1: {
    width: 7,
    height: 11,
    marginLeft: 16,
  },
  photosRowParent: {
    alignItems: "center",
    marginTop: 10,
    flexDirection: "row",
  },
  viewDetails: {
    width: 120,
    lineHeight: 24,
    fontSize: FontSize.pxRegular_size,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  buttonPrimary: {
    backgroundColor: Color.orange_200,
    paddingHorizontal: Padding.p_85xl,
    paddingVertical: Padding.p_3xs,
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  frameParent: {
    paddingHorizontal: Padding.p_xs,
    paddingBottom: Padding.p_xs,
    marginTop: 14,
    alignSelf: "stretch",
  },
  view1: {
    borderRadius: Border.br_5xs,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    overflow: "hidden",
    alignSelf: "stretch",
    backgroundColor: Color.white,
  },
  technicalCompetition1: {
    height: 260,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  listItems: {
    height: 788,
    alignSelf: "stretch",
  },
  searchResultsBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  technicalCompetition: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 896,
    width: "100%",
    flex: 1,
  },
});

export default TechnicalCompetition;
