import React, { useState, useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { TextInput } from "react-native-paper";
import StudentOtp from "../components/StudentOtp";
import Property1READIconyes from "../components/Property1READIconyes";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Padding, Border } from "../GlobalStyles";

const StudentLoginPersonalForm = () => {
  const [buttonVisible, setButtonVisible] = useState(false);
  const navigation = useNavigation();

  const openButton = useCallback(() => {
    setButtonVisible(true);
  }, []);

  const closeButton = useCallback(() => {
    setButtonVisible(false);
  }, []);

  return (
    <>
      <View style={styles.studentLoginPersonalForm}>
        <ScrollView
          style={styles.searchResultsBody}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.searchResultsBodyContent}
        >
          <View style={styles.listHeader}>
            <Text style={styles.personalInformation}>Personal information</Text>
          </View>
          <View style={styles.listItems}>
            <View style={styles.form}>
              <TextInput
                style={styles.outlinedtextOnlyNoIcon}
                label="First name"
                placeholder="Enter First name"
                mode="outlined"
                right={
                  <TextInput.Icon
                    style={{ marginTop: "50%" }}
                    name="account-edit"
                  />
                }
                placeholderTextColor="#9eaab6"
                outlineColor="#9eaab6"
                activeOutlineColor="#3b7beb"
                theme={{ colors: { text: "#000" } }}
              />
              <TextInput
                style={styles.outlinedtextOnlyNoIcon1}
                label="Last name"
                placeholder="Enter Last name"
                mode="outlined"
                right={
                  <TextInput.Icon
                    style={{ marginTop: "50%" }}
                    name="account-edit-outline"
                  />
                }
                placeholderTextColor="#9eaab6"
                outlineColor="#9eaab6"
                activeOutlineColor="#3b7beb"
                theme={{ colors: { text: "#000" } }}
              />
              <TextInput
                style={styles.outlinedtextOnlyNoIcon1}
                label="Gender"
                placeholder="Enter Gender"
                mode="outlined"
                right={
                  <TextInput.Icon
                    style={{ marginTop: "50%" }}
                    name="gender-male-female"
                  />
                }
                placeholderTextColor="#9eaab6"
                outlineColor="#9eaab6"
                activeOutlineColor="#3b7beb"
                theme={{ colors: { text: "#000" } }}
              />
              <TextInput
                style={styles.outlinedtextOnlyNoIcon1}
                label="Age"
                placeholder="Enter Age"
                mode="outlined"
                right={
                  <TextInput.Icon
                    style={{ marginTop: "50%" }}
                    name="numeric-9-plus-box-multiple-outline"
                  />
                }
                placeholderTextColor="#9eaab6"
                outlineColor="#9eaab6"
                activeOutlineColor="#3b7beb"
                theme={{ colors: { text: "#000" } }}
              />
              <TextInput
                style={styles.outlinedtextOnlyNoIcon1}
                label="Mobile no"
                placeholder="Enter Mobile"
                mode="outlined"
                right={
                  <TextInput.Icon
                    style={{ marginTop: "50%" }}
                    name="cellphone-message"
                  />
                }
                placeholderTextColor="#9eaab6"
                outlineColor="#9eaab6"
                activeOutlineColor="#3b7beb"
                theme={{
                  fonts: {
                    regular: { fontFamily: "Work Sans", fontWeight: "Regular" },
                  },
                  colors: { text: "#000" },
                }}
              />
              <View style={[styles.buttonWrapper, styles.buttonLayout]}>
                <Property1READIconyes
                  actionButtonText="Send OTP"
                  actionButtonLabel={require("../assets/vector3.png")}
                  property1READIconyesPosition="unset"
                  property1READIconyesBorderRadius={90}
                  property1READIconyesBackgroundColor="#1262ae"
                  property1READIconyesWidth="unset"
                  property1READIconyesHeight={30}
                  property1READIconyesOverflow="hidden"
                  readLineHeight={18}
                  readFontFamily="WorkSans-Regular"
                  onButtonPress={openButton}
                />
              </View>
              <TouchableOpacity
                style={[styles.buttonPrimary, styles.buttonLayout]}
                activeOpacity={0.2}
                onPress={() => navigation.navigate("StudentLoginAcedaicsForm")}
              >
                <Text style={[styles.viewDetails, styles.viewDetailsTypo]}>
                  Next
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>

      <Modal animationType="fade" transparent visible={buttonVisible}>
        <View style={styles.buttonOverlay}>
          <Pressable style={styles.buttonBg} onPress={closeButton} />
          <StudentOtp onClose={closeButton} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  iconLayout: {
    width: 32,
    height: 32,
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  viewDetailsTypo: {
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  buttonLayout: {
    width: 339,
    marginTop: 20,
  },
  buttonOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  buttonBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  personalInformation: {
    fontFamily: FontFamily.interRegular,
    color: Color.lightslategray,
    textAlign: "left",
    fontSize: FontSize.pxRegular_size,
  },
  listHeader: {
    paddingBottom: Padding.p_2xs,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon: {
    height: 56,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 20,
    height: 56,
    alignSelf: "stretch",
  },
  buttonWrapper: {
    borderRadius: Border.br_3xs,
    alignItems: "flex-end",
    overflow: "hidden",
    height: 32,
  },
  viewDetails: {
    lineHeight: 24,
    color: Color.white,
    width: 120,
    fontSize: FontSize.pxRegular_size,
  },
  buttonPrimary: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.orange_200,
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  form: {
    height: 473,
    alignSelf: "stretch",
  },
  listItems: {
    marginTop: 10,
  },
  searchResultsBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  studentLoginPersonalForm: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 611,
    width: "100%",
    flex: 1,
  },
});

export default StudentLoginPersonalForm;
