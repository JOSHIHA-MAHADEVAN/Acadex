import * as React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { Pressable, StyleSheet, Text, View, ScrollView } from "react-native";
import { Image } from "expo-image";
import { Color, FontSize, FontFamily, Padding, Border } from "../GlobalStyles";

const Certificates = () => {
  return (
    <View style={styles.certificates}>
      <ScrollView
        style={styles.offersBody}
        horizontal={false}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.offersBodyScrollViewContent}
      >
        <View style={styles.offersList}>
          <View style={styles.offerCardShadowBox}>
            <View style={styles.viewFlexBox}>
              <View style={[styles.onlineCourseWrapper, styles.wrapperFlexBox]}>
                <Text style={[styles.onlineCourse, styles.exploreTypo]}>
                  Online Course
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart5.png")}
              />
            </View>
            <Text
              style={[
                styles.machineLearningFromContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.machineLearningFrom}>
                Machine Learning From Basic to Advanced
              </Text>
              <Text style={styles.textTypo}>{` `}</Text>
              <Text style={styles.inUdemy}>{`in Udemy `}</Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.image7Wrapper}>
                <Image
                  style={[styles.image7Icon, styles.iconPosition]}
                  contentFit="cover"
                  source={require("../assets/image-71.png")}
                />
              </View>
              <View style={styles.machineLearningFromBasicToWrapper}>
                <Text
                  style={[styles.machineLearningFrom1, styles.exploreClr]}
                >{`Machine Learning From Basic to Advanced ertification course conduted by Udemy!
Date: Aug 3,2022.`}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
          <View style={[styles.offerCard1, styles.offerCardShadowBox]}>
            <View style={styles.viewFlexBox}>
              <View style={[styles.onlineCourseWrapper, styles.wrapperFlexBox]}>
                <Text style={[styles.onlineCourse, styles.exploreTypo]}>
                  Internship
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart.png")}
              />
            </View>
            <Text
              style={[
                styles.machineLearningFromContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text
                style={styles.machineLearningFrom}
              >{`Data Analytics and Visualization Virtual Experience `}</Text>
              <Text style={styles.textTypo}>{` `}</Text>
              <Text style={styles.inUdemy}>conducted by accenture</Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.image7Wrapper}>
                <Image
                  style={styles.image8Icon}
                  contentFit="cover"
                  source={require("../assets/image-83.png")}
                />
              </View>
              <View style={styles.machineLearningFromBasicToWrapper}>
                <Text
                  style={[styles.machineLearningFrom1, styles.exploreClr]}
                >{`Data Analytics and Visualization Virtual Experience Internship conducted by accenture!
Date: Sept 27,2022.  `}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
          <View style={[styles.offerCard2, styles.offerCardShadowBox]}>
            <View style={styles.viewFlexBox}>
              <View style={[styles.onlineCourseWrapper, styles.wrapperFlexBox]}>
                <Text style={[styles.onlineCourse, styles.exploreTypo]}>
                  Project competition
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart.png")}
              />
            </View>
            <Text
              style={[
                styles.machineLearningFromContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.machineLearningFrom}>
                Ideathon 2.0 Business Plan Competition-2022
              </Text>
              <Text style={styles.textTypo}>{` `}</Text>
              <Text
                style={styles.inUdemy}
              >{`conducted by KALINGA UNIVERSITY `}</Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.image7Wrapper}>
                <Image
                  style={styles.image8Icon}
                  contentFit="cover"
                  source={require("../assets/image-84.png")}
                />
              </View>
              <View style={styles.machineLearningFromBasicToWrapper}>
                <Text
                  style={[styles.machineLearningFrom1, styles.exploreClr]}
                >{`Ideathon 2.0 Buiness Plan Competition-2022 Project competition conducted by KALINGA UNIVERSITY!
Date: Nov 16,2022.  `}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
          <View style={[styles.offerCard3, styles.offerCardShadowBox]}>
            <View style={styles.viewFlexBox}>
              <View style={[styles.onlineCourseWrapper, styles.wrapperFlexBox]}>
                <Text style={[styles.onlineCourse, styles.exploreTypo]}>
                  Project competition
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart.png")}
              />
            </View>
            <Text
              style={[
                styles.machineLearningFromContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.machineLearningFrom}>
                SAMYUJ - BRIDGE BUILDING
              </Text>
              <Text style={styles.textTypo}>{` `}</Text>
              <Text
                style={styles.inUdemy}
              >{`conducted by PSG COLLEGE OF TECHNOLOGY `}</Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.image7Wrapper}>
                <Image
                  style={[styles.image8Icon2, styles.iconPosition]}
                  contentFit="cover"
                  source={require("../assets/image-85.png")}
                />
              </View>
              <View style={styles.machineLearningFromBasicToWrapper}>
                <Text
                  style={[styles.machineLearningFrom1, styles.exploreClr]}
                >{`SAMYU - BRIDGE BUILDING Project competition conducted by PSG COLLEGE OF TECHNOLOGY!
Date: Feb 19,2023.  `}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: "#fff",
  },
  offersBodyScrollViewContent: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 19,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  certificates1Clr: {
    color: Color.black,
    textAlign: "left",
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  wrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  exploreTypo: {
    textAlign: "center",
    fontSize: FontSize.size_smi,
  },
  frameGroupSpaceBlock: {
    marginTop: 7,
    alignSelf: "stretch",
  },
  iconPosition: {
    height: 71,
    top: 1,
    left: 0,
    position: "absolute",
  },
  exploreClr: {
    color: Color.lightslategray,
    fontFamily: FontFamily.robotoRegular,
  },
  offerCardShadowBox: {
    paddingVertical: Padding.p_smi,
    paddingHorizontal: Padding.p_mini,
    borderRadius: Border.br_5xs,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    justifyContent: "center",
    alignSelf: "stretch",
    backgroundColor: Color.white,
  },
  onlineCourse: {
    textTransform: "uppercase",
    color: Color.white,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
  },
  onlineCourseWrapper: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.mediumaquamarine,
    paddingHorizontal: Padding.p_6xs,
    paddingVertical: Padding.p_11xs,
    flexDirection: "row",
  },
  iconHeart: {
    width: 16,
    height: 16,
    overflow: "hidden",
  },
  machineLearningFrom: {
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
  },
  textTypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  inUdemy: {
    fontFamily: FontFamily.robotoRegular,
  },
  machineLearningFromContainer: {
    fontSize: FontSize.size_lg,
    lineHeight: 24,
    textAlign: "left",
    color: Color.black,
  },
  image7Icon: {
    width: 104,
    height: 71,
    top: 1,
  },
  image7Wrapper: {
    height: 72,
    width: 104,
  },
  machineLearningFrom1: {
    fontSize: FontSize.size_xs,
    lineHeight: 18,
    textAlign: "left",
    alignSelf: "stretch",
  },
  machineLearningFromBasicToWrapper: {
    marginLeft: 16,
    flex: 1,
  },
  vectorIcon: {
    width: 7,
    height: 11,
    marginLeft: 16,
  },
  frameGroup: {
    alignItems: "center",
    flexDirection: "row",
  },
  image8Icon: {
    top: 0,
    left: 0,
    height: 72,
    width: 104,
    position: "absolute",
  },
  offerCard1: {
    marginTop: 14,
  },
  offerCard2: {
    marginTop: 14,
  },
  image8Icon2: {
    width: 103,
  },
  offerCard3: {
    marginTop: 14,
  },
  offersList: {
    flex: 1,
  },
  offersBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  certificates: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 1151,
    width: "100%",
    flex: 1,
  },
});

export default Certificates;
