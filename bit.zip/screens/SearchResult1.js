import React, { useState, useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Dimensions,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import Carousel from "react-native-reanimated-carousel";
import Photo1Image from "../components/Photo1Image";
import Photo2Image from "../components/Photo2Image";
import Photo3Image from "../components/Photo3Image";
import Photo4Image from "../components/Photo4Image";
import Photo5Image from "../components/Photo5Image";
import Photo6Image from "../components/Photo6Image";
import Photo1Image7 from "../components/Photo1Image7";
import Photo2Image7 from "../components/Photo2Image7";
import Photo3Image7 from "../components/Photo3Image7";
import Photo4Image7 from "../components/Photo4Image7";
import Photo5Image7 from "../components/Photo5Image7";
import Photo6Image7 from "../components/Photo6Image7";
import Photo1Image2 from "../components/Photo1Image2";
import Photo2Image2 from "../components/Photo2Image2";
import Photo3Image2 from "../components/Photo3Image2";
import Photo4Image2 from "../components/Photo4Image2";
import Photo5Image2 from "../components/Photo5Image2";
import Photo6Image2 from "../components/Photo6Image2";
import Photo1Image3 from "../components/Photo1Image3";
import Photo2Image3 from "../components/Photo2Image3";
import Photo3Image3 from "../components/Photo3Image3";
import Photo4Image3 from "../components/Photo4Image3";
import Photo5Image3 from "../components/Photo5Image3";
import Photo6Image3 from "../components/Photo6Image3";
import Photo1Image4 from "../components/Photo1Image4";
import Photo2Image4 from "../components/Photo2Image4";
import Photo3Image4 from "../components/Photo3Image4";
import Photo4Image4 from "../components/Photo4Image4";
import Photo5Image4 from "../components/Photo5Image4";
import Photo6Image4 from "../components/Photo6Image4";
import Photo1Image5 from "../components/Photo1Image5";
import Photo2Image5 from "../components/Photo2Image5";
import Photo3Image5 from "../components/Photo3Image5";
import Photo4Image5 from "../components/Photo4Image5";
import Photo5Image5 from "../components/Photo5Image5";
import Photo6Image5 from "../components/Photo6Image5";
import Sort1 from "../components/Sort1";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const SearchResult1 = () => {
  const [photosRowItems, setPhotosRowItems] = useState([
    <Photo1Image />,
    <Photo2Image />,
    <Photo3Image />,
    <Photo4Image />,
    <Photo5Image />,
    <Photo6Image />,
  ]);
  const [photosRow1Items, setPhotosRow1Items] = useState([
    <Photo1Image7 />,
    <Photo2Image7 />,
    <Photo3Image7 />,
    <Photo4Image7 />,
    <Photo5Image7 />,
    <Photo6Image7 />,
  ]);
  const [photosRow2Items, setPhotosRow2Items] = useState([
    <Photo1Image2 />,
    <Photo2Image2 />,
    <Photo3Image2 />,
    <Photo4Image2 />,
    <Photo5Image2 />,
    <Photo6Image2 />,
  ]);
  const [photosRow3Items, setPhotosRow3Items] = useState([
    <Photo1Image3 />,
    <Photo2Image3 />,
    <Photo3Image3 />,
    <Photo4Image3 />,
    <Photo5Image3 />,
    <Photo6Image3 />,
  ]);
  const [photosRow4Items, setPhotosRow4Items] = useState([
    <Photo1Image4 />,
    <Photo2Image4 />,
    <Photo3Image4 />,
    <Photo4Image4 />,
    <Photo5Image4 />,
    <Photo6Image4 />,
  ]);
  const [photosRow5Items, setPhotosRow5Items] = useState([
    <Photo1Image5 />,
    <Photo2Image5 />,
    <Photo3Image5 />,
    <Photo4Image5 />,
    <Photo5Image5 />,
    <Photo6Image5 />,
  ]);
  const [sort01IconVisible, setSort01IconVisible] = useState(false);

  const openSort01Icon = useCallback(() => {
    setSort01IconVisible(true);
  }, []);

  const closeSort01Icon = useCallback(() => {
    setSort01IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.searchResult1}>
        <ScrollView
          style={styles.searchResultsBody}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.searchResultsBodyContent}
        >
          <View style={[styles.listHeader, styles.listFlexBox]}>
            <Text style={[styles.resultsFound, styles.resultsFoundClr]}>
              6 results found
            </Text>
            <Pressable style={styles.sort01} onPress={openSort01Icon}>
              <Image
                style={styles.iconLayout}
                contentFit="cover"
                source={require("../assets/sort-01.png")}
              />
            </Pressable>
          </View>
          <View style={[styles.listItems, styles.listFlexBox]}>
            <View style={styles.paperPresentation}>
              <View style={[styles.view1, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        Paper presentation
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart5.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>{`Datacon `}</Text>
                    <Text style={styles.paperPresentationEvent}>
                      Paper presentation event conducted by BIT
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={styles.photosRow}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRowItems}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.paperPresentationEventConduWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Paper presentation event conducted by the department AI&DS! 
Date:Sept 12,2023
Time:9.00am-12.00pm        `}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.paperPresentation}>
              <View style={[styles.view2, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        Technical Competition
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>{`Tech-Palooza `}</Text>
                    <Text style={styles.paperPresentationEvent}>
                      Technical Competition event conducted by KCT
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={styles.photosRow}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRow1Items}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.technicalCompetitionConducteWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Technical Competition conducted by the department ECE!
Date:Oct 1,2023
Time:10.00am-12:30pm`}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.paperPresentation}>
              <View style={[styles.view3, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        webinar
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>Free</Text>
                    <Text style={styles.text}>{` `}</Text>
                    <Text style={styles.paperPresentationEvent}>
                      Webinar conducted by PSG Institute Of Technology
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={styles.photosRow}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRow2Items}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.technicalCompetitionConducteWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Webinar conducted by the department ISE!
Date:Oct 21,2023
Time:11.00am-12:00pm`}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.paperPresentation}>
              <View style={[styles.view4, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        Project presentation
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>{`Tech-jamboree `}</Text>
                    <Text style={styles.paperPresentationEvent}>
                      Project presentation event conducted by BIT
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={[styles.photosRow3, styles.photosFlexBox]}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRow3Items}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.technicalCompetitionConducteWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Project presentation conducted by the department EEE!
Date:Oct 26,2023
Time:9.00am-12:30pm`}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.paperPresentation}>
              <View style={[styles.view5, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        Internship
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>Accenture Internship</Text>
                    <Text style={styles.paperPresentationEvent}>
                      {" "}
                      event conducted by FORAGE
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={styles.photosRow}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRow4Items}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.technicalCompetitionConducteWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Data Visualization Internship conducted by the Accenture!
Date:Oct 30-Nov 30,2023
Time:90 days`}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.paperPresentation}>
              <View style={[styles.view6, styles.viewShadowBox]}>
                <Image
                  style={styles.line3Icon}
                  contentFit="cover"
                  source={require("../assets/line3.png")}
                />
                <View style={styles.frameParent}>
                  <View style={[styles.frameGroup, styles.listFlexBox]}>
                    <View
                      style={[
                        styles.paperPresentationWrapper,
                        styles.buttonPrimaryFlexBox,
                      ]}
                    >
                      <Text
                        style={[
                          styles.paperPresentation1,
                          styles.viewDetailsFlexBox,
                        ]}
                      >
                        Online Course
                      </Text>
                    </View>
                    <Image
                      style={styles.iconHeart}
                      contentFit="cover"
                      source={require("../assets/icon--heart.png")}
                    />
                  </View>
                  <Text
                    style={[
                      styles.dataconPaperPresentationContainer,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text style={styles.dataconTypo}>Web Development</Text>
                    <Text style={styles.paperPresentationEvent}>
                      {" "}
                      course conducted by UDEMY
                    </Text>
                  </Text>
                  <View
                    style={[
                      styles.photosRowParent,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <View style={styles.photosRow}>
                      <Carousel
                        style={styles.carousel}
                        width={130}
                        mode="normal"
                        autoPlay={true}
                        loop={true}
                        data={photosRow5Items}
                        renderItem={({ item }) => item}
                      />
                    </View>
                    <View style={styles.technicalCompetitionConducteWrapper}>
                      <Text
                        style={[
                          styles.paperPresentationEvent1,
                          styles.resultsFoundClr,
                        ]}
                      >{`Web Development course conducted by Udemy!
Date:Dec 9 - Dec12 2023
Time:9.00am-12:30pm`}</Text>
                    </View>
                    <Image
                      style={styles.vectorIcon}
                      contentFit="cover"
                      source={require("../assets/vector-1.png")}
                    />
                  </View>
                  <View
                    style={[
                      styles.buttonPrimary,
                      styles.buttonPrimarySpaceBlock,
                    ]}
                  >
                    <Text
                      style={[styles.viewDetails, styles.viewDetailsFlexBox]}
                    >
                      Register
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      <Modal animationType="fade" transparent visible={sort01IconVisible}>
        <View style={styles.sort01IconOverlay}>
          <Pressable style={styles.sort01IconBg} onPress={closeSort01Icon} />
          <Sort1 onClose={closeSort01Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  eventsTopBar: {
    backgroundColor: "#fff",
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  listFlexBox: {
    justifyContent: "space-between",
    alignSelf: "stretch",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  eventsFlexBox: {
    textAlign: "left",
    color: Color.black,
  },
  iconLayout1: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  resultsFoundClr: {
    color: Color.lightslategray,
    textAlign: "left",
  },
  viewShadowBox: {
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    borderRadius: Border.br_5xs,
    overflow: "hidden",
    backgroundColor: Color.white,
  },
  buttonPrimaryFlexBox: {
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  viewDetailsFlexBox: {
    textAlign: "center",
    color: Color.white,
  },
  buttonPrimarySpaceBlock: {
    marginTop: 10,
    alignSelf: "stretch",
  },
  photosFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  resultsFound: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
  },
  sort01IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  sort01IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  sort01: {
    width: 17,
    height: 15,
  },
  listHeader: {
    paddingBottom: Padding.p_2xs,
    alignItems: "center",
    flexDirection: "row",
  },
  line3Icon: {
    maxWidth: "100%",
    height: 1,
    overflow: "hidden",
    alignSelf: "stretch",
    width: "100%",
  },
  paperPresentation1: {
    fontSize: FontSize.size_smi,
    textTransform: "uppercase",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
  },
  paperPresentationWrapper: {
    backgroundColor: Color.mediumaquamarine,
    paddingHorizontal: Padding.p_6xs,
    paddingVertical: Padding.p_11xs,
  },
  iconHeart: {
    width: 16,
    height: 16,
    overflow: "hidden",
  },
  frameGroup: {
    alignItems: "center",
    flexDirection: "row",
  },
  dataconTypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  paperPresentationEvent: {
    fontFamily: FontFamily.robotoRegular,
  },
  dataconPaperPresentationContainer: {
    fontSize: FontSize.size_lg,
    lineHeight: 24,
    textAlign: "left",
    color: Color.black,
  },
  carousel: {
    width: 120,
    height: 90,
  },
  photosRow: {
    height: 90,
    width: 120,
  },
  paperPresentationEvent1: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.robotoRegular,
    lineHeight: 18,
    alignSelf: "stretch",
  },
  paperPresentationEventConduWrapper: {
    width: 123,
    marginLeft: 16,
  },
  vectorIcon: {
    width: 7,
    height: 11,
    marginLeft: 16,
  },
  photosRowParent: {
    alignItems: "center",
    flexDirection: "row",
  },
  viewDetails: {
    width: 120,
    lineHeight: 24,
    fontSize: FontSize.pxRegular_size,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  buttonPrimary: {
    backgroundColor: Color.orange_200,
    paddingHorizontal: Padding.p_85xl,
    paddingVertical: Padding.p_3xs,
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  frameParent: {
    paddingHorizontal: Padding.p_xs,
    paddingBottom: Padding.p_xs,
    marginTop: 14,
    alignSelf: "stretch",
  },
  view1: {
    width: 339,
  },
  paperPresentation: {
    height: 260,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  technicalCompetitionConducteWrapper: {
    width: 156,
    marginLeft: 16,
  },
  view2: {
    alignSelf: "stretch",
  },
  text: {
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
  },
  view3: {
    alignSelf: "stretch",
  },
  photosRow3: {
    width: 120,
  },
  view4: {
    alignSelf: "stretch",
  },
  view5: {
    alignSelf: "stretch",
  },
  view6: {
    alignSelf: "stretch",
  },
  listItems: {
    height: 1560,
  },
  searchResultsBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  searchResult1: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 1738,
    width: "100%",
    flex: 1,
  },
});

export default SearchResult1;
