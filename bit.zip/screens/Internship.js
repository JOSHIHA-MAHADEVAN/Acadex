import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import Carousel from "react-native-reanimated-carousel";
import Photo1Image4 from "../components/Photo1Image4";
import Photo2Image4 from "../components/Photo2Image4";
import Photo3Image4 from "../components/Photo3Image4";
import Photo4Image4 from "../components/Photo4Image4";
import Photo5Image4 from "../components/Photo5Image4";
import Photo6Image4 from "../components/Photo6Image4";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const Internship = () => {
  const [photosRowItems, setPhotosRowItems] = useState([
    <Photo1Image4 />,
    <Photo2Image4 />,
    <Photo3Image4 />,
    <Photo4Image4 />,
    <Photo5Image4 />,
    <Photo6Image4 />,
  ]);

  return (
    <View style={styles.internship}>
      <ScrollView
        style={styles.searchResultsBody}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.searchResultsBodyContent}
      >
        <View style={[styles.listHeader, styles.viewFlexBox]}>
          <Text style={[styles.resultsFound, styles.resultsFoundClr]}>
            results found
          </Text>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/sort-01.png")}
          />
        </View>
        <View style={styles.listItems}>
          <View style={styles.internship1}>
            <View style={styles.view1}>
              <Image
                style={styles.line3Icon}
                contentFit="cover"
                source={require("../assets/line3.png")}
              />
              <View style={styles.frameParent}>
                <View style={styles.viewFlexBox}>
                  <View
                    style={[
                      styles.internshipWrapper,
                      styles.buttonPrimaryFlexBox,
                    ]}
                  >
                    <Text
                      style={[styles.internship2, styles.internship2FlexBox]}
                    >
                      Internship
                    </Text>
                  </View>
                  <Image
                    style={styles.iconHeart}
                    contentFit="cover"
                    source={require("../assets/icon--heart.png")}
                  />
                </View>
                <Text
                  style={[
                    styles.accentureInternshipEventContainer,
                    styles.buttonPrimarySpaceBlock,
                  ]}
                >
                  <Text style={styles.internshipTypo}>
                    Accenture Internship
                  </Text>
                  <Text style={styles.eventConductedBy}>
                    {" "}
                    event conducted by FORAGE
                  </Text>
                </Text>
                <View
                  style={[
                    styles.photosRowParent,
                    styles.buttonPrimarySpaceBlock,
                  ]}
                >
                  <View style={styles.photosRow}>
                    <Carousel
                      style={styles.carousel}
                      width={130}
                      mode="normal"
                      autoPlay={true}
                      loop={true}
                      data={photosRowItems}
                      renderItem={({ item }) => item}
                    />
                  </View>
                  <View style={styles.dataVisualizationInternshipWrapper}>
                    <Text
                      style={[
                        styles.dataVisualizationInternship,
                        styles.resultsFoundClr,
                      ]}
                    >{`Data Visualization Internship conducted by the Accenture!
Date:Oct 30-Nov 30,2023
Time:90 days`}</Text>
                  </View>
                  <Image
                    style={styles.frameChild1}
                    contentFit="cover"
                    source={require("../assets/vector-1.png")}
                  />
                </View>
                <View
                  style={[styles.buttonPrimary, styles.buttonPrimarySpaceBlock]}
                >
                  <Text style={[styles.viewDetails, styles.internship2FlexBox]}>
                    Register
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  eventsFlexBox: {
    textAlign: "left",
    color: Color.black,
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  resultsFoundClr: {
    color: Color.lightslategray,
    textAlign: "left",
  },
  buttonPrimaryFlexBox: {
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  internship2FlexBox: {
    textAlign: "center",
    color: Color.white,
  },
  buttonPrimarySpaceBlock: {
    marginTop: 10,
    alignSelf: "stretch",
  },
  resultsFound: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
  },
  vectorIcon: {
    width: 17,
    height: 15,
  },
  listHeader: {
    paddingBottom: Padding.p_2xs,
  },
  line3Icon: {
    maxWidth: "100%",
    height: 1,
    overflow: "hidden",
    alignSelf: "stretch",
    width: "100%",
  },
  internship2: {
    fontSize: FontSize.size_smi,
    textTransform: "uppercase",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
  },
  internshipWrapper: {
    backgroundColor: Color.mediumaquamarine,
    paddingHorizontal: Padding.p_6xs,
    paddingVertical: Padding.p_11xs,
  },
  iconHeart: {
    width: 16,
    height: 16,
    overflow: "hidden",
  },
  internshipTypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  eventConductedBy: {
    fontFamily: FontFamily.robotoRegular,
  },
  accentureInternshipEventContainer: {
    fontSize: FontSize.size_lg,
    lineHeight: 24,
    textAlign: "left",
    color: Color.black,
  },
  carousel: {
    width: 120,
    height: 90,
  },
  photosRow: {
    height: 90,
    width: 120,
  },
  dataVisualizationInternship: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.robotoRegular,
    lineHeight: 18,
    alignSelf: "stretch",
  },
  dataVisualizationInternshipWrapper: {
    width: 156,
    marginLeft: 16,
  },
  frameChild1: {
    width: 7,
    height: 11,
    marginLeft: 16,
  },
  photosRowParent: {
    alignItems: "center",
    marginTop: 10,
    flexDirection: "row",
  },
  viewDetails: {
    width: 120,
    lineHeight: 24,
    fontSize: FontSize.pxRegular_size,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  buttonPrimary: {
    backgroundColor: Color.orange_200,
    paddingHorizontal: Padding.p_85xl,
    paddingVertical: Padding.p_3xs,
    borderRadius: Border.br_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  frameParent: {
    paddingHorizontal: Padding.p_xs,
    paddingBottom: Padding.p_xs,
    marginTop: 14,
    alignSelf: "stretch",
  },
  view1: {
    borderRadius: Border.br_5xs,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    overflow: "hidden",
    alignSelf: "stretch",
    backgroundColor: Color.white,
  },
  internship1: {
    height: 260,
    paddingBottom: Padding.p_4xs,
    alignSelf: "stretch",
  },
  listItems: {
    height: 788,
    alignSelf: "stretch",
  },
  searchResultsBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  internship: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 896,
    width: "100%",
    flex: 1,
  },
});

export default Internship;
