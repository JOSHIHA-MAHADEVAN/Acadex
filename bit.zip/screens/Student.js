import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  ScrollView,
  View,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import { Badge } from "react-native-paper";
import Carousel from "react-native-reanimated-carousel";
import PhotoImage5 from "../components/PhotoImage5";
import PhotoImage4 from "../components/PhotoImage4";
import PhotoImage3 from "../components/PhotoImage3";
import PhotoImage2 from "../components/PhotoImage2";
import PhotoImage1 from "../components/PhotoImage1";
import PhotoImage from "../components/PhotoImage";
import { useNavigation } from "@react-navigation/native";
import UpcomingFlightsSectionContaine from "../components/UpcomingFlightsSectionContaine";
import FormWithButtonsAndCategories from "../components/FormWithButtonsAndCategories";
import TrendingDestinationsContainer1 from "../components/TrendingDestinationsContainer1";
import FormSection from "../components/FormSection";
import { Padding, FontFamily, FontSize, Color } from "../GlobalStyles";

const Student = () => {
  const [photosRowItems, setPhotosRowItems] = useState([
    <PhotoImage5 />,
    <PhotoImage4 />,
    <PhotoImage3 />,
    <PhotoImage2 />,
    <PhotoImage1 />,
    <PhotoImage />,
  ]);
  const navigation = useNavigation();

  return (
    <View style={styles.student}>
      <ScrollView
        style={styles.exploreMainView}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.exploreMainViewContent}
      >
        <View style={styles.photosRow}>
          <Carousel
            style={styles.carousel}
            width={353}
            mode="normal"
            autoPlay={true}
            loop={true}
            pagingEnabled={false}
            data={photosRowItems}
            renderItem={({ item }) => item}
          />
        </View>
        <View style={styles.exploreContent}>
          <UpcomingFlightsSectionContaine />
          <FormWithButtonsAndCategories />
          <TrendingDestinationsContainer1 />
          <FormSection
            dimensions={require("../assets/offer-image.png")}
            carDimensions={require("../assets/offer-image1.png")}
            onOfferCardPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
            }
            onOfferCardPress1={() =>
              navigation.navigate("BottomTabsRoot", { screen: "Certificates" })
            }
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: "#fff",
  },
  exploreMainViewContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "center",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    padding: Padding.p_base,
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  exploreTypo: {
    marginTop: 14,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_smi,
  },
  carousel: {
    width: 343,
    height: 197,
  },
  photosRow: {
    width: 343,
    alignItems: "center",
    flexDirection: "row",
  },
  exploreContent: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  exploreMainView: {
    alignSelf: "stretch",
    flex: 1,
  },
  student: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    width: "100%",
    flex: 1,
  },
});

export default Student;
