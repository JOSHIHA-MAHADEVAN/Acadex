import * as React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Text,
  StyleSheet,
  View,
  TouchableOpacity,
  Pressable,
} from "react-native";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import Signup from "../components/Signup";
import Login from "../components/Login";
import Online1 from "../components/Online1";
import SignupFaculty from "../components/SignupFaculty";
import LoginFaculty from "../components/LoginFaculty";
import Offline1 from "../components/Offline1";
import { TextInput } from "react-native-paper";
import { FontFamily, FontSize, Border, Padding, Color } from "../GlobalStyles";

const TopTab = createMaterialTopTabNavigator();
const StudentSignup = () => {
  return (
    <View style={[styles.studentSignup, styles.studentFlexBox]}>
      <View style={styles.facultySignupBody}>
        <View style={styles.event2}>
          <TopTab.Navigator
            style={styles.facultyToptabSignupToptabs}
            tabBar={({ state, descriptors, navigation, position }) => {
              const [activeItems] = React.useState([
                <Online1 />,
                <LoginFaculty />,
              ]);
              const [normalItems] = React.useState([
                <SignupFaculty />,
                <Offline1 />,
              ]);
              const activeIndex = state.index;
              return (
                <View style={styles.topTabBarStyle}>
                  {normalItems.map((item, index) => {
                    const isFocused = state.index === index;
                    return (
                      <TouchableOpacity
                        key={index}
                        onPress={() => {
                          navigation.navigate({
                            name: state.routes[index].name,
                            merge: true,
                          });
                        }}
                      >
                        {activeIndex === index ? activeItems[index] : item}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              );
            }}
          >
            <TopTab.Screen name="signup" component={Signup} />
            <TopTab.Screen name="login" component={Login} />
          </TopTab.Navigator>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  facultyToptabSignupToptabs: {
    width: "100%",
  },
  topTabBarStyle: {
    borderRadius: 32,
    backgroundColor: "#f3f5f9",
    width: 313,
    flexDirection: "row",
    padding: 4,
    alignItems: "flex-start",
    justifyContent: "flex-start",
    minHeight: 44,
    zIndex: 1,
  },
  studentFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  doctorFlexBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  areYouATypo: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xs,
    textAlign: "center",
  },
  event2: {
    borderRadius: Border.br_xs,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    width: 341,
    height: 356,
    padding: Padding.p_sm,
    backgroundColor: Color.white,
  },
  facultySignupBody: {
    paddingHorizontal: Padding.p_mini,
    paddingVertical: Padding.p_base,
    alignSelf: "stretch",
    alignItems: "center",
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
  studentSignup: {
    flex: 1,
    width: "100%",
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    justifyContent: "center",
  },
});

export default StudentSignup;
