import React, { useState, useCallback } from "react";
import {
  ScrollView,
  Pressable,
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  ImageBackground,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Description from "../components/Description";
import Property1READIconyes from "../components/Property1READIconyes";
import FormCheckbox from "../components/FormCheckbox";
import Passwod from "../components/Passwod";
import ProfilePhoto from "../components/ProfilePhoto";
import { FontFamily, FontSize, Border, Color, Padding } from "../GlobalStyles";

const Profile = () => {
  const [frameButton1Visible, setFrameButton1Visible] = useState(false);
  const [checkbox2Visible, setCheckbox2Visible] = useState(false);
  const navigation = useNavigation();
  const [profileImageVisible, setProfileImageVisible] = useState(false);

  const openFrameButton1 = useCallback(() => {
    setFrameButton1Visible(true);
  }, []);

  const closeFrameButton1 = useCallback(() => {
    setFrameButton1Visible(false);
  }, []);

  const openCheckbox2 = useCallback(() => {
    setCheckbox2Visible(true);
  }, []);

  const closeCheckbox2 = useCallback(() => {
    setCheckbox2Visible(false);
  }, []);

  const openProfileImage = useCallback(() => {
    setProfileImageVisible(true);
  }, []);

  const closeProfileImage = useCallback(() => {
    setProfileImageVisible(false);
  }, []);

  return (
    <>
      <ImageBackground
        style={styles.profileIcon}
        resizeMode="cover"
        source={require("../assets/profile.png")}
      >
        <ScrollView
          style={styles.profileSection}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.profileSectionScrollViewContent}
        >
          <View style={[styles.header, styles.checkboxFlexBox]}>
            <Pressable
              style={[styles.iconBackWrapper, styles.wrapperFlexBox]}
              onPress={() => navigation.goBack()}
            >
              <Image
                style={styles.iconBack}
                contentFit="cover"
                source={require("../assets/icon--back2.png")}
              />
            </Pressable>
            <TouchableOpacity
              style={[styles.fluentedit48RegularWrapper, styles.wrapperFlexBox]}
              activeOpacity={0.2}
              onPress={openFrameButton1}
            >
              <View style={[styles.fluentedit48Regular, styles.wrapperFlexBox]}>
                <Image
                  style={styles.vectorIcon}
                  contentFit="cover"
                  source={require("../assets/vector4.png")}
                />
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.profileBody}>
            <View style={styles.profileDrawer}>
              <View style={styles.profileDetails}>
                <View style={styles.nameParticulars}>
                  <View style={styles.lathikaSheherParent}>
                    <Text style={styles.lathikaSheher}>
                      <Text style={styles.lathika}>{`Lathika `}</Text>
                      <Text style={styles.sheher}>(she/her)</Text>
                    </Text>
                    <Text
                      style={[
                        styles.bannariAmmanInstitute,
                        styles.iLikeHardworkTypo,
                      ]}
                    >
                      Bannari Amman Institute Of Technology
                    </Text>
                  </View>
                </View>
                <Text style={[styles.iLikeHardwork, styles.iLikeHardworkTypo]}>
                  I like hardwork, leadership and everything about gaining
                  knowledge! :)
                </Text>
                <View style={styles.profileDetailsChild} />
                <View style={styles.list}>
                  <View style={styles.checkboxShadowBox}>
                    <View style={styles.checkbox}>
                      <View style={styles.fluentbookExclamationMark2Parent}>
                        <Image
                          style={[
                            styles.fluentbookExclamationMark2Icon,
                            styles.iconLayout,
                          ]}
                          contentFit="cover"
                          source={require("../assets/fluentbookexclamationmark20filled.png")}
                        />
                        <Text style={styles.title}>Registration History</Text>
                      </View>
                      <TouchableOpacity
                        style={[styles.buttonWrapper, styles.wrapperFlexBox]}
                        activeOpacity={0.2}
                        onPress={() =>
                          navigation.navigate("BottomTabsRoot", {
                            screen: "Register",
                          })
                        }
                      >
                        <Property1READIconyes
                          actionButtonText="Read"
                          actionButtonLabel={require("../assets/vector5.png")}
                          property1READIconyesPosition="unset"
                          property1READIconyesBorderRadius={16}
                          property1READIconyesBackgroundColor="#ff9134"
                          property1READIconyesWidth={96}
                          property1READIconyesHeight={30}
                          property1READIconyesOverflow="unset"
                          readLineHeight={18}
                          readFontFamily="WorkSans-Regular"
                          onButtonPress={() =>
                            navigation.navigate("BottomTabsRoot", {
                              screen: "Register",
                            })
                          }
                        />
                      </TouchableOpacity>
                    </View>
                    <Text
                      style={[styles.checkYourAll, styles.titleTypo]}
                      numberOfLines={1}
                    >
                      Check your All Registration History
                    </Text>
                  </View>
                  <FormCheckbox
                    iconImageUrl={require("../assets/icon.png")}
                    sectionTitle="Registered Events"
                    onCheckboxPress={() =>
                      navigation.navigate("BottomTabsRoot", {
                        screen: "Register",
                      })
                    }
                  />
                  <FormCheckbox
                    iconImageUrl={require("../assets/icon1.png")}
                    sectionTitle="Personal Information"
                    propColor="#091f44"
                  />
                  <Pressable
                    style={[styles.checkbox1, styles.checkboxShadowBox]}
                    onPress={openCheckbox2}
                  >
                    <View style={styles.iconParent}>
                      <Image
                        style={[styles.icon, styles.iconLayout]}
                        contentFit="cover"
                        source={require("../assets/icon2.png")}
                      />
                      <Text style={[styles.title1, styles.titleTypo]}>
                        Reset password
                      </Text>
                    </View>
                    <Image
                      style={styles.vectorIcon1}
                      contentFit="cover"
                      source={require("../assets/vector6.png")}
                    />
                  </Pressable>
                  <TouchableOpacity
                    style={[styles.checkbox2, styles.checkboxShadowBox]}
                    accessible="true"
                    activeOpacity={0.2}
                    onPress={() => navigation.navigate("StudentSignup")}
                  >
                    <View style={styles.iconParent}>
                      <Image
                        style={[styles.icon, styles.iconLayout]}
                        contentFit="cover"
                        source={require("../assets/icon3.png")}
                      />
                      <Text style={[styles.title2, styles.titleTypo]}>
                        Log out
                      </Text>
                    </View>
                    <Image
                      style={styles.vectorIcon1}
                      contentFit="cover"
                      source={require("../assets/vector6.png")}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <TouchableOpacity
              style={styles.profileImage}
              activeOpacity={0.2}
              onPress={openProfileImage}
            >
              <Image
                style={styles.ovalIcon}
                contentFit="cover"
                source={require("../assets/oval1.png")}
              />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>

      <Modal animationType="fade" transparent visible={frameButton1Visible}>
        <View style={styles.frameButton1Overlay}>
          <Pressable
            style={styles.frameButton1Bg}
            onPress={closeFrameButton1}
          />
          <Description onClose={closeFrameButton1} />
        </View>
      </Modal>

      <Modal animationType="fade" transparent visible={checkbox2Visible}>
        <View style={styles.checkbox2Overlay}>
          <Pressable style={styles.checkbox2Bg} onPress={closeCheckbox2} />
          <Passwod onClose={closeCheckbox2} />
        </View>
      </Modal>

      <Modal animationType="fade" transparent visible={profileImageVisible}>
        <View style={styles.profileImageOverlay}>
          <Pressable
            style={styles.profileImageBg}
            onPress={closeProfileImage}
          />
          <ProfilePhoto onClose={closeProfileImage} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  profileSectionScrollViewContent: {
    flexDirection: "column",
    paddingTop: 30,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  checkboxFlexBox: {
    justifyContent: "space-between",
    flexDirection: "row",
  },
  wrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  iLikeHardworkTypo: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
    alignSelf: "stretch",
  },
  iconLayout: {
    borderRadius: Border.br_3xs,
    overflow: "hidden",
  },
  titleTypo: {
    fontFamily: FontFamily.workSansRegular,
    textTransform: "capitalize",
    lineHeight: 16,
    color: Color.black1,
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
  },
  checkboxShadowBox: {
    shadowColor: "rgba(24, 57, 107, 0.05)",
    backgroundColor: Color.gray_200,
    borderRadius: Border.br_base,
    elevation: 20,
    shadowRadius: 20,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    padding: Padding.p_base,
    alignSelf: "stretch",
  },
  exploreTypo: {
    marginTop: 14,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_smi,
  },
  iconBack: {
    width: 24,
    overflow: "hidden",
    height: 24,
  },
  iconBackWrapper: {
    padding: Padding.p_7xs,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.12)",
    borderRadius: Border.br_5xl,
    justifyContent: "center",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    backgroundColor: Color.white,
  },
  frameButton1Overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  frameButton1Bg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  vectorIcon: {
    width: 21,
    height: 21,
  },
  fluentedit48Regular: {
    padding: Padding.p_11xs,
    overflow: "hidden",
  },
  fluentedit48RegularWrapper: {
    padding: Padding.p_7xs,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.12)",
    borderRadius: Border.br_5xl,
    justifyContent: "center",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    backgroundColor: Color.white,
  },
  header: {
    padding: Padding.p_base,
    justifyContent: "space-between",
    alignSelf: "stretch",
  },
  lathika: {
    fontSize: 24,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
  },
  sheher: {
    fontSize: FontSize.size_mini,
    fontWeight: "300",
    fontFamily: FontFamily.interLight,
  },
  lathikaSheher: {
    textAlign: "left",
    color: Color.black,
    alignSelf: "stretch",
  },
  bannariAmmanInstitute: {
    marginTop: 2,
    color: Color.lightslategray,
  },
  lathikaSheherParent: {
    width: 262,
  },
  nameParticulars: {
    alignSelf: "stretch",
  },
  iLikeHardwork: {
    lineHeight: 24,
    marginTop: 16,
    color: Color.black,
    fontSize: FontSize.pxRegular_size,
  },
  profileDetailsChild: {
    borderStyle: "solid",
    borderColor: "#e6e9f0",
    borderTopWidth: 1,
    height: 1,
    marginTop: 16,
    alignSelf: "stretch",
  },
  fluentbookExclamationMark2Icon: {
    width: 32,
    height: 28,
  },
  title: {
    lineHeight: 18,
    fontWeight: "600",
    fontFamily: FontFamily.montserratSemiBold,
    marginLeft: 4,
    color: Color.black1,
    fontSize: FontSize.pxRegular_size,
    textAlign: "left",
    flex: 1,
  },
  fluentbookExclamationMark2Parent: {
    width: 182,
    alignItems: "center",
    flexDirection: "row",
  },
  buttonWrapper: {
    height: 30,
  },
  checkbox: {
    borderRadius: Border.br_base,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  checkYourAll: {
    marginTop: 16,
    alignSelf: "stretch",
  },
  checkbox2Overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  checkbox2Bg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  icon: {
    maxWidth: "100%",
    maxHeight: "100%",
  },
  title1: {
    marginLeft: 4,
    flex: 1,
  },
  iconParent: {
    alignItems: "center",
    flexDirection: "row",
  },
  vectorIcon1: {
    width: 7,
    height: 13,
  },
  checkbox1: {
    marginTop: 16,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  title2: {
    marginLeft: 4,
  },
  checkbox2: {
    marginTop: 16,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  list: {
    width: 339,
    marginTop: 16,
  },
  profileDetails: {
    flex: 1,
  },
  profileDrawer: {
    borderTopLeftRadius: Border.br_3xs,
    borderTopRightRadius: Border.br_3xs,
    shadowColor: "rgba(0, 0, 0, 0.14)",
    paddingHorizontal: Padding.p_base,
    paddingVertical: 43,
    zIndex: 0,
    elevation: 20,
    shadowRadius: 20,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    backgroundColor: Color.white,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  profileImageOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  profileImageBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  ovalIcon: {
    width: 90,
    height: 90,
  },
  profileImage: {
    position: "absolute",
    top: 0,
    left: 16,
    zIndex: 1,
    flexDirection: "row",
  },
  profileBody: {
    paddingTop: 42,
    marginTop: 50,
    alignSelf: "stretch",
  },
  profileSection: {
    alignSelf: "stretch",
    flex: 1,
  },
  profileIcon: {
    width: "100%",
    height: 933,
    flex: 1,
  },
});

export default Profile;
