import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import Carousel from "react-native-reanimated-carousel";
import Image12 from "../components/Image12";
import Image11 from "../components/Image11";
import Image10 from "../components/Image10";
import Image9 from "../components/Image9";
import Image8 from "../components/Image8";
import Image7 from "../components/Image7";
import Image13 from "../components/Image13";
import Image121 from "../components/Image121";
import Image111 from "../components/Image111";
import Image101 from "../components/Image101";
import Image91 from "../components/Image91";
import Image81 from "../components/Image81";
import Image131 from "../components/Image131";
import Image122 from "../components/Image122";
import Image112 from "../components/Image112";
import Image102 from "../components/Image102";
import Image92 from "../components/Image92";
import Image82 from "../components/Image82";
import { Color, FontSize, FontFamily, Padding, Border } from "../GlobalStyles";

const Register = () => {
  const [frameCarouselItems, setFrameCarouselItems] = useState([
    <Image12 />,
    <Image11 />,
    <Image10 />,
    <Image9 />,
    <Image8 />,
    <Image7 />,
  ]);
  const [frameCarousel1Items, setFrameCarousel1Items] = useState([
    <Image13 />,
    <Image121 />,
    <Image111 />,
    <Image101 />,
    <Image91 />,
    <Image81 />,
  ]);
  const [frameCarousel2Items, setFrameCarousel2Items] = useState([
    <Image131 />,
    <Image122 />,
    <Image112 />,
    <Image102 />,
    <Image92 />,
    <Image82 />,
  ]);

  return (
    <View style={styles.register}>
      <ScrollView
        style={styles.offersBody}
        horizontal={false}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.offersBodyScrollViewContent}
      >
        <View style={styles.offersList}>
          <View style={styles.offerCardShadowBox}>
            <View style={styles.viewFlexBox}>
              <View
                style={[styles.paperPresentationWrapper, styles.wrapperFlexBox]}
              >
                <Text style={[styles.paperPresentation, styles.exploreTypo]}>
                  Paper presentation
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart5.png")}
              />
            </View>
            <Text
              style={[
                styles.dataconPaperPresentationContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.datacon}>{`Datacon `}</Text>
              <Text style={styles.paperPresentationEvent}>
                Paper presentation event conducted by BIT
              </Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.wrapper}>
                <Carousel
                  style={styles.carousel}
                  width={104}
                  mode="normal"
                  autoPlay={true}
                  loop={true}
                  data={frameCarouselItems}
                  renderItem={({ item }) => item}
                />
              </View>
              <View style={styles.paperPresentationEventConduWrapper}>
                <Text
                  style={[styles.paperPresentationEvent1, styles.exploreClr]}
                >{`Paper presentation event conducted by the department AI&DS! 
Date:Sept 12,2023
Time:9.00am-12.00pm        `}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-16.png")}
              />
            </View>
          </View>
          <View style={[styles.offerCard1, styles.offerCardShadowBox]}>
            <View style={styles.viewFlexBox}>
              <View
                style={[styles.paperPresentationWrapper, styles.wrapperFlexBox]}
              >
                <Text style={[styles.technicalCompetition, styles.exploreTypo]}>
                  Technical Competition
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart.png")}
              />
            </View>
            <Text
              style={[
                styles.dataconPaperPresentationContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.techPalooza}>Tech-Palooza</Text>
              <Text style={styles.datacon}>{` `}</Text>
              <Text style={styles.paperPresentationEvent}>
                Technical Competition event conducted by KCT
              </Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.wrapper}>
                <Carousel
                  style={styles.carousel1}
                  width={104}
                  mode="normal"
                  autoPlay={true}
                  loop={true}
                  data={frameCarousel1Items}
                  renderItem={({ item }) => item}
                />
              </View>
              <View style={styles.technicalCompetitionConducteWrapper}>
                <Text
                  style={[styles.paperPresentationEvent1, styles.exploreClr]}
                >{`Technical Competition conducted by the department ECE!
Date:Oct 1,2023
Time:10.00am-12:30pm`}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
          <View style={[styles.offerCard2, styles.offerCardShadowBox]}>
            <View style={styles.viewFlexBox}>
              <View
                style={[styles.paperPresentationWrapper, styles.wrapperFlexBox]}
              >
                <Text style={[styles.paperPresentation, styles.exploreTypo]}>
                  webinar
                </Text>
              </View>
              <Image
                style={styles.iconHeart}
                contentFit="cover"
                source={require("../assets/icon--heart.png")}
              />
            </View>
            <Text
              style={[
                styles.dataconPaperPresentationContainer,
                styles.frameGroupSpaceBlock,
              ]}
            >
              <Text style={styles.techPalooza}>{`Free `}</Text>
              <Text style={styles.paperPresentationEvent}>
                Webinar conducted by PSG Institute Of Technology
              </Text>
            </Text>
            <View style={[styles.frameGroup, styles.frameGroupSpaceBlock]}>
              <View style={styles.wrapper}>
                <Carousel
                  style={styles.carousel1}
                  width={104}
                  mode="normal"
                  autoPlay={true}
                  loop={true}
                  data={frameCarousel2Items}
                  renderItem={({ item }) => item}
                />
              </View>
              <View style={styles.technicalCompetitionConducteWrapper}>
                <Text
                  style={[styles.paperPresentationEvent1, styles.exploreClr]}
                >{`Webinar conducted by the department ISE!
Date:Oct 21,2023
Time:11.00am-12:00pm`}</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector-15.png")}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: "#fff",
  },
  offersBodyScrollViewContent: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 19,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  viewFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  registeredFlexBox: {
    textAlign: "left",
    color: Color.black,
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  wrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  exploreTypo: {
    textAlign: "center",
    fontSize: FontSize.size_smi,
  },
  frameGroupSpaceBlock: {
    marginTop: 7,
    alignSelf: "stretch",
  },
  exploreClr: {
    color: Color.lightslategray,
    fontFamily: FontFamily.robotoRegular,
  },
  offerCardShadowBox: {
    paddingVertical: Padding.p_smi,
    paddingHorizontal: Padding.p_mini,
    borderRadius: Border.br_5xs,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.03)",
    justifyContent: "center",
    alignSelf: "stretch",
    backgroundColor: Color.white,
  },
  paperPresentation: {
    color: Color.white,
    textTransform: "uppercase",
    textAlign: "center",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
    fontSize: FontSize.size_smi,
  },
  paperPresentationWrapper: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.mediumaquamarine,
    paddingHorizontal: Padding.p_6xs,
    paddingVertical: Padding.p_11xs,
    flexDirection: "row",
  },
  iconHeart: {
    width: 16,
    height: 16,
    overflow: "hidden",
  },
  datacon: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  paperPresentationEvent: {
    fontFamily: FontFamily.robotoRegular,
  },
  dataconPaperPresentationContainer: {
    fontSize: FontSize.size_lg,
    lineHeight: 24,
    textAlign: "left",
    color: Color.black,
  },
  carousel: {
    width: 104.44332122802734,
    height: 71.89148712158203,
  },
  wrapper: {
    width: 104,
    height: 72,
  },
  paperPresentationEvent1: {
    fontSize: FontSize.size_xs,
    lineHeight: 18,
    color: Color.lightslategray,
    textAlign: "left",
    alignSelf: "stretch",
  },
  paperPresentationEventConduWrapper: {
    width: 123,
    marginLeft: 16,
  },
  vectorIcon: {
    width: 7,
    height: 11,
    marginLeft: 16,
  },
  frameGroup: {
    alignItems: "center",
    flexDirection: "row",
  },
  technicalCompetition: {
    display: "flex",
    width: 160,
    color: Color.white,
    textTransform: "uppercase",
    textAlign: "center",
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    lineHeight: 18,
    fontSize: FontSize.size_smi,
    justifyContent: "center",
    alignItems: "center",
  },
  techPalooza: {
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
  },
  carousel1: {
    width: 104.443115234375,
    height: 71.8914794921875,
  },
  technicalCompetitionConducteWrapper: {
    marginLeft: 16,
    flex: 1,
  },
  offerCard1: {
    marginTop: 14,
  },
  offerCard2: {
    marginTop: 14,
  },
  offersList: {
    flex: 1,
  },
  offersBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  register: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 817,
    width: "100%",
    flex: 1,
  },
});

export default Register;
