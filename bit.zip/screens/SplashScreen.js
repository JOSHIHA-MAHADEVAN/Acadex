import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, ImageBackground } from "react-native";

const SplashScreen = () => {
  return (
    <ImageBackground
      style={styles.splashScreenIcon}
      resizeMode="cover"
      source={require("../assets/splashscreen.png")}
    >
      <View style={styles.logoSection}>
        <Image
          style={styles.logoIcon}
          contentFit="cover"
          source={require("../assets/logo.png")}
        />
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  logoIcon: {
    position: "absolute",
    height: "264.08%",
    width: "96.44%",
    top: "-82.04%",
    right: "1.78%",
    bottom: "-82.04%",
    left: "1.78%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  logoSection: {
    width: 285,
    height: 89,
  },
  splashScreenIcon: {
    flex: 1,
    width: "100%",
    height: 1070,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default SplashScreen;
