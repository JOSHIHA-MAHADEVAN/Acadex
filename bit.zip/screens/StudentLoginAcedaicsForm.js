import * as React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { TextInput } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Padding, Border } from "../GlobalStyles";

const StudentLoginAcedaicsForm = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.studentLoginAcedaicsForm}>
      <ScrollView
        style={styles.searchResultsBody}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.searchResultsBodyContent}
      >
        <View style={styles.listHeader}>
          <Text style={styles.acedamicInformation}>Acedamic information</Text>
        </View>
        <View style={styles.listItems}>
          <View style={styles.form}>
            <TextInput
              style={styles.outlinedtextIconLayout}
              label="University name"
              placeholder="eg. Anna University"
              mode="outlined"
              right={
                <TextInput.Icon style={{ marginTop: "50%" }} name="school" />
              }
              placeholderTextColor="#9eaab6"
              outlineColor="#9eaab6"
              activeOutlineColor="#3b7beb"
              theme={{ colors: { text: "#000" } }}
            />
            <TextInput
              style={[
                styles.outlinedtextOnlyNoIcon1,
                styles.outlinedtextIconLayout,
              ]}
              label="Branch of study"
              placeholder="eg. Artificial Intelligence And Data Science"
              mode="outlined"
              right={
                <TextInput.Icon
                  style={{ marginTop: "50%" }}
                  name="book-multiple"
                />
              }
              placeholderTextColor="#9eaab6"
              outlineColor="#9eaab6"
              activeOutlineColor="#3b7beb"
              theme={{ colors: { text: "#000" } }}
            />
            <TextInput
              style={[
                styles.outlinedtextOnlyNoIcon1,
                styles.outlinedtextIconLayout,
              ]}
              label="College name"
              placeholder="eg. Bannari Amman Institute Of Technology"
              mode="outlined"
              right={
                <TextInput.Icon
                  style={{ marginTop: "50%" }}
                  name="school-outline"
                />
              }
              placeholderTextColor="#9eaab6"
              outlineColor="#9eaab6"
              activeOutlineColor="#3b7beb"
              theme={{ colors: { text: "#000" } }}
            />
            <TextInput
              style={[
                styles.outlinedtextOnlyNoIcon1,
                styles.outlinedtextIconLayout,
              ]}
              label="Github Link"
              placeholder="Enter Github Link"
              mode="outlined"
              right={
                <TextInput.Icon style={{ marginTop: "50%" }} name="link-box" />
              }
              placeholderTextColor="#9eaab6"
              outlineColor="#9eaab6"
              activeOutlineColor="#3b7beb"
              theme={{ colors: { text: "#000" } }}
            />
            <TextInput
              style={[
                styles.outlinedtextOnlyNoIcon1,
                styles.outlinedtextIconLayout,
              ]}
              label="LinkedIn link"
              placeholder="Enter LinkedIn link"
              mode="outlined"
              right={
                <TextInput.Icon
                  style={{ marginTop: "50%" }}
                  name="link-box-outline"
                />
              }
              placeholderTextColor="#9eaab6"
              outlineColor="#9eaab6"
              activeOutlineColor="#3b7beb"
              theme={{
                fonts: {
                  regular: { fontFamily: "Work Sans", fontWeight: "Regular" },
                },
                colors: { text: "#000" },
              }}
            />
            <Text style={styles.uploadText}>Upload Student ID</Text>
            <View style={styles.uploadIdStudent}>
              <View style={[styles.rectangleParent, styles.groupChildPosition]}>
                <View style={[styles.groupChild, styles.groupChildPosition]} />
                <Image
                  style={styles.iconAlternateCloudUpload}
                  contentFit="cover"
                  source={require("../assets/-icon-alternate-cloud-upload.png")}
                />
                <Text style={styles.uploadImage}>Upload Image</Text>
              </View>
            </View>
            <TouchableOpacity
              style={[styles.buttonPrimary, styles.innerFlexBox]}
              activeOpacity={0.2}
              onPress={() =>
                navigation.navigate("BottomTabsRoot", { screen: "Student" })
              }
            >
              <Text style={[styles.viewDetails, styles.viewDetailsTypo]}>
                Submit
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  innerFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  viewDetailsTypo: {
    textAlign: "center",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  iconLayout: {
    height: 32,
    width: 32,
  },
  frameLayout: {
    height: 5,
    width: 5,
  },
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  groupChildPosition: {
    left: "50%",
    height: 40,
    width: 170,
    position: "absolute",
  },
  acedamicInformation: {
    fontFamily: FontFamily.interRegular,
    color: Color.lightslategray,
    textAlign: "left",
    fontSize: FontSize.pxRegular_size,
  },
  listHeader: {
    paddingBottom: Padding.p_2xs,
    alignSelf: "stretch",
  },
  outlinedtextOnlyNoIcon1: {
    marginTop: 20,
  },
  uploadText: {
    fontSize: 10,
    fontFamily: FontFamily.ralewayRegular,
    display: "flex",
    width: 188,
    height: 17,
    marginTop: 20,
    textAlign: "left",
    color: Color.black,
    alignItems: "center",
  },
  groupChild: {
    marginLeft: -85,
    top: 0,
    borderRadius: 20,
    backgroundColor: Color.cornflowerblue,
  },
  iconAlternateCloudUpload: {
    height: "38.5%",
    width: "13.47%",
    top: "30%",
    right: "8.72%",
    bottom: "31.5%",
    left: "77.8%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  uploadImage: {
    top: 9,
    left: 22,
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.adventProBold,
    color: Color.white,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    marginLeft: -47,
    top: -9,
  },
  uploadIdStudent: {
    height: 40,
    width: 170,
    marginTop: 20,
  },
  viewDetails: {
    lineHeight: 24,
    width: 120,
    color: Color.white,
    fontSize: FontSize.pxRegular_size,
  },
  buttonPrimary: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.orange_200,
    width: 339,
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_3xs,
    marginTop: 20,
    flexDirection: "row",
  },
  form: {
    height: 519,
    alignSelf: "stretch",
  },
  listItems: {
    marginTop: 10,
  },
  searchResultsBody: {
    alignSelf: "stretch",
    flex: 1,
  },
  studentLoginAcedaicsForm: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    height: 657,
    width: "100%",
    flex: 1,
  },
});

export default StudentLoginAcedaicsForm;
