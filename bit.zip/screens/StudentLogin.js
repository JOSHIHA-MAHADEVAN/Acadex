import * as React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  TouchableOpacity,
} from "react-native";
import { TextInput } from "react-native-paper";
import { FontFamily, Padding, Border, Color, FontSize } from "../GlobalStyles";

const StudentLogin = () => {
  return (
    <View style={[styles.studentLogin, styles.studentFlexBox]}>
      <View style={styles.facultyLoginBody}>
        <View style={styles.event2}>
          <View style={styles.facultyToptabLogin} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  group4: {
    backgroundColor: "#fff",
  },
  studentFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  studentTypo: {
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
  },
  facultyFlexBox: {
    paddingVertical: Padding.p_7xs,
    width: 153,
    flexDirection: "row",
    borderRadius: Border.br_13xl,
    paddingHorizontal: Padding.p_base,
    justifyContent: "center",
    alignItems: "center",
  },
  loginTypo: {
    color: Color.white,
    textAlign: "center",
    lineHeight: 24,
    fontSize: FontSize.pxRegular_size,
  },
  outlinedtextIconLayout: {
    height: 56,
    alignSelf: "stretch",
  },
  areYouATypo: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    textAlign: "center",
  },
  facultyToptabLogin: {
    backgroundColor: Color.ghostwhite,
    padding: Padding.p_9xs,
    flexDirection: "row",
    borderRadius: Border.br_13xl,
    alignSelf: "stretch",
  },
  event2: {
    borderRadius: Border.br_xs,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    width: 341,
    height: 356,
    padding: Padding.p_sm,
    backgroundColor: Color.white,
  },
  facultyLoginBody: {
    paddingHorizontal: Padding.p_mini,
    paddingVertical: Padding.p_base,
    alignSelf: "stretch",
    alignItems: "center",
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
  },
  studentLogin: {
    flex: 1,
    width: "100%",
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    justifyContent: "center",
  },
});

export default StudentLogin;
